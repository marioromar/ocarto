# Ocarto v1.77 — modificación segura de tramos

- «Modificar tramo» permite elegir el inicio y final en cualquier orden en líneas abiertas, sin invertir ni duplicar partes de la geometría.
- En áreas, sustituye el arco más corto entre los vértices marcados y conserva intacto el resto del anillo.
- Tiene en cuenta los desplazamientos del objeto, mantiene vértices y metadata originales y actualiza las coordenadas de los nuevos puntos.
- Los trazos nuevos se convierten a curvas Bézier naturales; los símbolos de edificios y ruinas siguen con segmentos rectos y nuevos vértices esquina. Las esquinas existentes se conservan.
- Valida la geometría final antes de guardar. En áreas revisa el contorno y los huecos; si el resultado se cruza o invalida un hueco, no modifica el mapa.
- Rechaza geometrías Bézier de entrada para no degradarlas a segmentos rectos; se pueden duplicar y convertir si se quiere mantener el original.
- Solo permite editar objetos y capas desbloqueados. La acción se puede deshacer.

## Verificación

- Pruebas de sustitución abierta con extremos en ambos sentidos y de anillos cerrados conservando la ruta no seleccionada.
- `npm test`: 62 pruebas ejecutadas.
- Sintaxis de `reshape-tools.js` y del script de interfaz verificada.
- Prueba de navegador omitida porque Chromium no está instalado.
