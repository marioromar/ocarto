const assert=require('assert');const T=require('../line-tools.js');
const source=[[0,0],[1,0]],target=[[4,-1],[4,1]],r=T.extendToNearest(source,[target],3);
assert.deepStrictEqual(r.line,[[0,0],[4,0]]);assert.equal(r.distance,3);assert.equal(r.endIndex,1);assert.deepStrictEqual(r.target,[4,0]);
assert.deepStrictEqual(source,[[0,0],[1,0]]);assert.deepStrictEqual(target,[[4,-1],[4,1]]);
assert.throws(()=>T.extendToNearest([[0,0],[1,0]],[[[4,1],[4,-1]]],2),/distancia máxima/);
assert.throws(()=>T.extendToNearest([[0,0],[1,0]],[[[0.5,1],[0.5,-1]]],2),/Ningún tramo cruza/,'no mueve el extremo hacia atrás');
const collinear=T.extendToNearest([[0,0],[1,0]],[[[2,0],[3,0]]],4);assert.deepStrictEqual(collinear.line,[[0,0],[2,0]]);
console.log('✓ prolongación recta hasta cualquier segmento, con orientación y distancia validadas');
