const assert=require('assert');const M=require('../measure-tools.js');
const square=[{x:0,y:0},{x:10,y:0},{x:10,y:10},{x:0,y:10}],hole=[{x:2,y:2},{x:4,y:2},{x:4,y:4},{x:2,y:4}];
assert.equal(M.measureArea(square,[hole]),96,'subtracts straight holes');assert.equal(M.measurePerimeter(square)+M.measurePerimeter(hole),48,'includes the outer and hole boundaries');
const scaled={offset:{x:3,y:4},toWorld:p=>({x:p.x*2,y:p.y*2})};assert.equal(M.measureArea(square,[hole],scaled),384,'applies object offsets and map scale');assert.equal(M.measurePerimeter(square,scaled)+M.measurePerimeter(hole,scaled),96);
const curved=[{x:0,y:0,outTangent:{x:0,y:-5}},{x:10,y:0,inTangent:{x:0,y:-5}},{x:10,y:10},{x:0,y:10}],area=M.measureArea(curved,[],{curved:true,steps:256});
assert.ok(Math.abs(area-130)<0.02,`samples Bézier area accurately (got ${area})`);
const arch=[{x:0,y:0,outTangent:{x:0,y:4}},{x:10,y:0,inTangent:{x:0,y:4}}];assert.ok(M.measureLine(arch,{steps:64})>10,'measures curved line length');
const oversized=square.map(p=>({x:p.x*2,y:p.y*2}));assert.throws(()=>M.measureArea(square,[oversized]),/supera el contorno/);
console.log('✓ medidas Bézier, superficie de huecos, offsets y escala');
