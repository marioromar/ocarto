const assert=require('assert');const R=require('../reshape-tools.js');const path=[[0,0],[1,0],[2,0],[3,0]],out=R.replace(path,[1,0],[3,0],[[1,0],[2,1],[3,0]]);assert.deepStrictEqual(out,[[0,0],[1,0],[2,1],[3,0]]);
assert.deepStrictEqual(R.replace(path,[3,0],[1,0],[[3,0],[2,1],[1,0]]),[[0,0],[1,0],[2,1],[3,0]],'reverse endpoint order keeps line ordering');
const ring=[[0,0],[4,0],[4,4],[0,4]],closed=R.replace(ring,[0,4],[4,0],[[0,4],[2,5],[4,0]],true);assert.deepStrictEqual(closed,[[0,4],[2,5],[4,0],[4,4]],'closed ring replaces only the shorter selected arc');assert.equal(new Set(closed.map(p=>p.join(','))).size,closed.length);
console.log('✓ modificación de tramos abiertos y anillos, en ambos sentidos');
