# Ocarto v1.78 — medición precisa de geometrías curvas

- «Medir selección» calcula la longitud de líneas Bézier y la superficie y el perímetro de áreas a partir de muestras de sus curvas, no de las cuerdas entre vértices.
- Resta el área de los huecos y suma sus bordes al perímetro total.
- Aplica el desplazamiento del objeto y transforma las coordenadas al CRS geográfico o de la nube LiDAR antes de medir.
- Usa muestreo configurable y acotado para limitar el trabajo en dispositivos modestos; el editor usa 64 segmentos por arco de curva.
- Si el área de huecos supera el área exterior, muestra el error sin dar una superficie negativa.

## Verificación

- Pruebas de área recta y Bézier, curva con área analítica conocida, perímetro exterior e interior, desplazamientos, escala y geometría incoherente.
- `npm test`: 63 pruebas ejecutadas.
- Sintaxis del nuevo módulo y los scripts de interfaz verificada.
- Prueba de navegador omitida porque Chromium no está instalado.
