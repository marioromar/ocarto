# Ocarto v1.82 — simplificación que protege quiebros cartográficos

- «Simplificar selección» conserva automáticamente entrantes pronunciados de áreas, aunque no estén etiquetados como esquina.
- La detección funciona igual con anillos horarios y antihorarios.
- Conserva también quiebros muy cerrados de líneas; pequeñas oscilaciones menores que la tolerancia aún se pueden simplificar.
- No cambia las limitaciones actuales: las curvas Bézier y las áreas con huecos siguen protegidas de esta herramienta.

## Verificación

- Pruebas de entrantes en ambos sentidos, quiebros de línea, ruido sub-tolerancia y geometría cerrada válida.
- `npm test`: 63 pruebas ejecutadas.
