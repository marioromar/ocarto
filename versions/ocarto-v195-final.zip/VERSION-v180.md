# Ocarto v1.80 — protección de entrantes agudos al convertir curvas

- La conversión «Polilínea → Bézier» conserva como esquina los vértices con un giro interior muy cerrado, aunque no estuvieran marcados manualmente.
- Se evitan tiradores de suavizado en esos puntos para que vaguadas, entrantes y quiebros estrechos no se redondeen al convertir.
- Las esquinas explícitas y la protección existente de edificios y ruinas se mantienen.

## Verificación

- Prueba específica de un entrante agudo y de sus vértices sin tiradores.
- `npm test`: 63 pruebas ejecutadas.
