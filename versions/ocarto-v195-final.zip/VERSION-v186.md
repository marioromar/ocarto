# Ocarto v1.86 — metadatos y esquinas protegidos al simplificar Bézier

- Se amplían las pruebas para confirmar que las líneas Bézier conservan los metadatos de los anclajes que permanecen.
- En áreas con huecos, se comprueba que los anclajes retenidos conservan sus propiedades originales.
- Una esquina o trazo marcado en el contorno o en cualquier hueco protege la geometría completa de la simplificación.
- No se cambia la forma de simplificación; este paquete fija con pruebas el comportamiento seguro existente.

## Verificación

- `npm test`: 63 pruebas ejecutadas, incluida la comprobación ampliada de metadatos y esquinas.
- Sintaxis de los 21 scripts inline comprobada.
- Prueba visual omitida porque Chromium no está instalado.
