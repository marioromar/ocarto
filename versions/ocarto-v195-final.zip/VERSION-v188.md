# Ocarto v1.88 — tiradores validados al editar Bézier

- Se amplía la validación de «Polilínea → Bézier» para comprobar el resultado curvo antes de aplicarlo.
- En áreas, se revisan el contorno exterior y todos los huecos en conjunto; en líneas, se valida la línea muestreada.
- Si la conversión introduce auto-intersecciones u otra geometría inválida, se cancela y se conserva el objeto original.
- Las esquinas marcadas, edificios y ruinas mantienen sus reglas existentes.

## Verificación

- Prueba del flujo manual para asegurar que la validación precede a la mutación del objeto.
- `npm test`: 63 pruebas ejecutadas.
- Sintaxis de los 21 scripts inline comprobada.
- Prueba visual omitida porque Chromium no está instalado.
