# Ocarto v1.87 — conversión a Bézier con validación topológica

- «Polilínea → Bézier» valida la geometría curva resultante antes de modificar el objeto.
- En áreas, comprueba juntos el contorno exterior y todos sus huecos; en líneas, valida el recorrido muestreado.
- Si la curva crea auto-intersecciones, huecos fuera o solapados, cancela la conversión y mantiene la geometría original.
- Se mantienen las reglas existentes para esquinas, edificios y ruinas.

## Verificación

- Prueba del flujo de conversión para comprobar que la validación ocurre antes de guardar el cambio.
- `npm test`: 63 pruebas ejecutadas.
- Sintaxis de los 21 scripts inline comprobada.
- Prueba visual omitida porque Chromium no está instalado.
