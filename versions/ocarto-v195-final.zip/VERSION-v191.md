# Ocarto v1.91 — tolerancia geométrica y esquinas al aplanar Bézier

- Se añaden pruebas que comparan muestras densas de la curva original con la polilínea y confirman que la desviación queda dentro de la tolerancia elegida.
- Los vértices marcados como esquina ignoran tiradores Bézier residuales durante el aplanado, para que los tramos lleguen rectos a la esquina.
- La metadata de las esquinas permanece en el resultado y se eliminan sus tiradores residuales.
- Se mantienen el límite topológico y la reducción de geometrías densas de la v1.90.

## Verificación

- `npm test`: 64 pruebas ejecutadas.
- Prueba geométrica densa de desviación y prueba de esquina con tiradores residuales.
- Sintaxis de los 21 scripts inline y del módulo Bézier comprobada.
- Prueba visual omitida porque Chromium no está instalado.
