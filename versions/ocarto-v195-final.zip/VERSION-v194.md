# Ocarto v1.94 — presupuesto común para contornos y huecos

- Se amplían las pruebas para áreas con varios huecos y geometrías densas.
- Confirma que el límite anticipado de generación se comparte entre el contorno exterior y todos los huecos.
- Confirma que el máximo topológico de 2.400 vértices incluye todos los anillos, que no se pierde ningún hueco y que se conservan metadatos de anclajes retenidos.
- La prueba comprueba la validez topológica del área reducida completa.

## Verificación

- `npm test`: 64 pruebas ejecutadas, con caso de dos huecos y límite acumulado.
- Sintaxis de los 21 scripts inline y del módulo Bézier comprobada.
- Prueba visual omitida porque Chromium no está instalado.
