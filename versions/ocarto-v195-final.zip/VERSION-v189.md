# Ocarto v1.89 — conversión Bézier a polilínea con tolerancia adaptativa

- «Bézier → polilínea» pregunta la desviación máxima en píxeles de pantalla y genera puntos adaptativamente según la curvatura.
- Convierte tanto el contorno exterior como todos los huecos de un área.
- Conserva la metadata de los anclajes originales y elimina los tiradores Bézier del resultado.
- Valida el resultado antes de aplicarlo; si no alcanza la tolerancia o la topología no es válida, conserva la curva original.
- Limita la conversión a 100.000 puntos y aborta si se supera la profundidad de subdivisión configurada.

## Verificación

- Pruebas de tolerancia, refinamiento, anclajes, huecos, validación topológica y límites de subdivisión.
- `npm test`: 64 pruebas ejecutadas.
- Sintaxis de los 21 scripts inline y el nuevo módulo comprobada.
- Prueba visual omitida porque Chromium no está instalado.
