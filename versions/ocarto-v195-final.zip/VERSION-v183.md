# Ocarto v1.83 — simplificación comprobada de líneas Bézier

- «Simplificar selección» también acepta líneas Bézier; usa muestras de la curva para buscar anclajes redundantes.
- Al fusionar segmentos, conserva las derivadas de los extremos y comprueba la distancia entre la curva original y la reconstruida.
- Solo aplica la reducción cuando el error muestreado queda dentro de la tolerancia elegida. Si no, deja la geometría intacta.
- Las esquinas explícitas se conservan. Las áreas Bézier y las áreas con huecos siguen protegidas.

## Verificación

- Prueba de fusión exacta de un Bézier cúbico subdividido, tiradores de extremos y esquina protegida.
- `npm test`: 63 pruebas ejecutadas.
- Sintaxis de los scripts inline verificada; prueba visual omitida porque Chromium no está instalado.
