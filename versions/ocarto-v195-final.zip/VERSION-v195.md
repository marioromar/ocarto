# Ocarto v1.95 — historial completo de geometrías Bézier

- Se añade una prueba ejecutable del historial de vértices para comprobar la conversión de Bézier a polilínea.
- Verifica que Deshacer restaura curva, tiradores, huecos y metadatos del objeto.
- Verifica que Rehacer retira los campos Bézier y reproduce exactamente la polilínea convertida.
- Confirma que la identidad del historial y la selección de vértice se conservan correctamente.

## Verificación

- `npm test`: 65 pruebas ejecutadas.
- Sintaxis de los scripts inline de `index.html` y del módulo Bézier comprobada.
