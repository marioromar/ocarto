# Ocarto v1.79 — conversión Bézier con esquinas protegidas

- «Polilínea → Bézier» usa el mismo generador de curvas naturales que el dibujo cartográfico, en lugar de volver a calcular tiradores a mano.
- Los vértices marcados como esquina no reciben tangentes de suavizado; sus posiciones y tipo se conservan al convertir.
- Bloquea la conversión cuando el símbolo es edificio, construcción o ruina para que un contorno recto no se redondee accidentalmente.
- Mantiene los metadatos y los agujeros del área; la conversión es reversible con «Bézier → polilínea» y queda en el historial de deshacer.

## Verificación

- Pruebas de tangentes normales, esquinas sin tiradores, protección de edificios y ruinas, fuentes inmutables y reglas de la interfaz.
- `npm test`: 63 pruebas ejecutadas.
- Sintaxis de `natural-curves.js` y scripts inline verificada.
- Prueba de navegador omitida porque Chromium no está instalado.
