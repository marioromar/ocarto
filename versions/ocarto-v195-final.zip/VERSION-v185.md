# Ocarto v1.85 — simplificación validada de áreas Bézier con huecos

- «Simplificar selección» también puede reducir anclajes redundantes en áreas Bézier con huecos.
- Valida conjuntamente el contorno exterior y todos los huecos antes y después de simplificar; rechaza cruces, huecos fuera del área o solapados.
- Comprueba la desviación muestreada de cada curva y solo acepta el cambio dentro de la tolerancia.
- Si no puede validar todos los anillos, conserva la geometría sin cambios.

## Verificación

- Pruebas de reducción en polígono curvo con hueco, validez topológica conjunta y tolerancia cero.
- `npm test`: 63 pruebas ejecutadas.
- Prueba visual omitida porque Chromium no está instalado.
