# Ocarto v1.81 — protección de entrantes independiente del sentido

- La conversión «Polilínea → Bézier» detecta los entrantes agudos de un área usando la orientación real de su anillo.
- El resultado conserva esos puntos como esquinas tanto si el contorno se recorre en sentido horario como antihorario.
- Se mantiene el suavizado de vértices convexos y los huecos válidos.

## Verificación

- Prueba de una muesca cóncava con los vértices en ambos sentidos.
- `npm test`: 63 pruebas ejecutadas.
