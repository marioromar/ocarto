# Ocarto v1.92 — cierre de anillos al convertir curvas

- Se amplían las pruebas del aplanado Bézier para cubrir el tramo que cierra el anillo exterior y los huecos.
- Comprueba que la desviación en la unión queda dentro de la tolerancia solicitada.
- Confirma que se conservan los metadatos del último anclaje original y que el primer punto no se duplica al cerrar.
- La prueba confirma que la lógica de cierre existente no necesita cambios.

## Verificación

- `npm test`: 64 pruebas ejecutadas, con comprobaciones del cierre y metadatos de anillos.
- Sintaxis de los 21 scripts inline y del módulo Bézier comprobada.
- Prueba visual omitida porque Chromium no está instalado.
