# Ocarto v1.76 — prolongación precisa de líneas

- «Prolongar hasta línea cercana» busca intersecciones de la prolongación recta de ambos extremos con todos los segmentos de las líneas destino compatibles, no solo con sus vértices finales.
- El límite de distancia se aplica desde el extremo original. Si ningún segmento cruza la prolongación dentro del límite, no se modifica el mapa.
- Las líneas destino Bézier se evalúan mediante una muestra densa de su curva. Una línea seleccionada Bézier se rechaza para conservarla intacta.
- Tiene en cuenta los desplazamientos de los objetos y conserva vértices, tipo de vértice y metadatos del extremo editado; actualiza coordenadas geográficas cuando corresponde.
- La edición se registra en deshacer/rehacer.

## Verificación

- Pruebas de cruce con el interior de un segmento, orientación de prolongación, límite de distancia, línea colineal y conservación de las geometrías de origen.
- `npm test`: 62 pruebas ejecutadas.
- Sintaxis de `line-tools.js` y del script de interfaz verificada.
- Prueba de navegador omitida porque Chromium no está instalado.
