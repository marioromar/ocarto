# Ocarto v1.93 — límite anticipado de puntos Bézier

- El aplanado adaptativo limita a 20.000 el total de vértices generados para una conversión, antes de que la geometría completa se almacene.
- Si se alcanza el límite, la operación se detiene inmediatamente y pide aumentar la tolerancia.
- La geometría que queda bajo ese tope sigue reduciéndose, si hace falta, al presupuesto de 2.400 vértices para la validación topológica.

## Verificación

- Prueba de una curva extrema que supera un límite configurado bajo y se interrumpe durante la generación.
- `npm test`: 64 pruebas ejecutadas.
- Sintaxis de los 21 scripts inline y del módulo Bézier comprobada.
- Prueba visual omitida porque Chromium no está instalado.
