# Ocarto v1.84 — simplificación segura de áreas Bézier

- «Simplificar selección» también puede reducir anclajes redundantes en áreas Bézier lisas sin huecos.
- Comprueba el anillo original y el reconstruido para rechazar auto-intersecciones.
- Compara la distancia muestreada entre ambas curvas y solo acepta el cambio dentro de la tolerancia indicada.
- Áreas con huecos y contornos con esquinas o guiones marcados siguen protegidos.

## Verificación

- Pruebas de reducción de un área curva lisa, validez del anillo, esquina protegida y tolerancia cero.
- `npm test`: 63 pruebas ejecutadas.
- Prueba visual omitida porque Chromium no está instalado.
