/* Medición cartográfica sobre geometrías rectas y curvas Bézier. */
(function(root){
  function validPoints(points,min){return Array.isArray(points)&&points.length>=min&&points.every(p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y))}
  function sample(points,closed,steps,forceCurve=false){
    if(!validPoints(points,closed?3:2)||!Number.isInteger(steps)||steps<1)throw Error('Geometría no válida para medir');
    const curved=forceCurve||points.some(p=>p.tangent||p.inTangent||p.outTangent),out=[{x:points[0].x,y:points[0].y}],count=closed?points.length:points.length-1;
    for(let i=0;i<count;i++){
      const a=points[i],b=points[(i+1)%points.length];
      if(!curved){out.push({x:b.x,y:b.y});continue}
      const dx=b.x-a.x,dy=b.y-a.y,av=a.outTangent||a.tangent||{x:dx/3,y:dy/3},bi=b.inTangent||(b.tangent?{x:-b.tangent.x,y:-b.tangent.y}:{x:-dx/3,y:-dy/3}),c1={x:a.x+av.x,y:a.y+av.y},c2={x:b.x+bi.x,y:b.y+bi.y};
      for(let j=1;j<=steps;j++){const t=j/steps,u=1-t;out.push({x:u*u*u*a.x+3*u*u*t*c1.x+3*u*t*t*c2.x+t*t*t*b.x,y:u*u*u*a.y+3*u*u*t*c1.y+3*u*t*t*c2.y+t*t*t*b.y})}
    }
    if(closed)out.pop();return out;
  }
  function options(opts={}){const offset=opts.offset||{x:0,y:0},transform=opts.toWorld||((p)=>p),steps=opts.steps??64;if(![offset.x,offset.y].every(Number.isFinite)||typeof transform!=='function'||!Number.isInteger(steps)||steps<1||steps>512)throw Error('Parámetros de medición no válidos');return{offset,transform,steps,curved:!!opts.curved}}
  function worldPoints(points,closed,opts){return sample(points,closed,opts.steps,opts.curved).map(p=>{const q=opts.transform({x:p.x+opts.offset.x,y:p.y+opts.offset.y});if(!q||!Number.isFinite(q.x)||!Number.isFinite(q.y))throw Error('Coordenadas transformadas no válidas');return q})}
  function measureLine(points,config={}){const opts=options(config),path=worldPoints(points,false,opts);let length=0;for(let i=1;i<path.length;i++)length+=Math.hypot(path[i].x-path[i-1].x,path[i].y-path[i-1].y);return length}
  function measurePerimeter(ring,config={}){const opts=options(config),path=worldPoints(ring,true,opts);let length=0;for(let i=0;i<path.length;i++){const a=path[i],b=path[(i+1)%path.length];length+=Math.hypot(b.x-a.x,b.y-a.y)}return length}
  function ringArea(ring,opts){const path=worldPoints(ring,true,opts);let twice=0;for(let i=0;i<path.length;i++){const a=path[i],b=path[(i+1)%path.length];twice+=a.x*b.y-b.x*a.y}return Math.abs(twice)/2}
  function measureArea(outer,holes=[],config={}){if(!Array.isArray(holes))throw Error('Huecos no válidos para medir');const opts=options(config),outside=ringArea(outer,opts),inside=holes.reduce((sum,hole)=>sum+ringArea(hole,opts),0),area=outside-inside;if(area< -Math.max(1e-8,outside*1e-10))throw Error('La superficie de los huecos supera el contorno');return Math.max(0,area)}
  root.OcartoMeasureTools={sample,measureLine,measurePerimeter,measureArea};if(typeof module!=='undefined'&&module.exports)module.exports=root.OcartoMeasureTools;
})(typeof window!=='undefined'?window:globalThis);
