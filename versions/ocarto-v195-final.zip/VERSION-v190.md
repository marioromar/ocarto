# Ocarto v1.90 — conversión de curvas densas dentro del límite topológico

- «Bézier → polilínea» reserva la mitad de la tolerancia para el aplanado y la otra mitad para reducir puntos, manteniendo acotada la desviación total.
- Si el resultado supera 2.400 vértices, lo simplifica dentro del presupuesto de tolerancia antes de validarlo.
- La geometría final deja margen bajo el límite de 2.500 vértices del validador topológico.
- Si no puede alcanzar ese límite con la tolerancia elegida, cancela sin cambiar el objeto e indica que se aumente la tolerancia.

## Verificación

- Caso de un área con 3.000 puntos: reducción acotada y anillo válido.
- Caso en que la tolerancia no permite llegar al límite: rechazo claro y sin mutación.
- `npm test`: 64 pruebas ejecutadas.
- Sintaxis de los 21 scripts inline y del módulo Bézier comprobada.
- Prueba visual omitida porque Chromium no está instalado.
