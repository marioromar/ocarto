/* Ocarto: edición geométrica avanzada de líneas, conservando la línea original. */
(function(root){
  function valid(line){return Array.isArray(line)&&line.length>=2&&line.every(p=>Array.isArray(p)&&Number.isFinite(p[0])&&Number.isFinite(p[1]))}
  function parallel(line,distance,side=1){
    if(!valid(line)) throw Error('Línea no válida');
    const d=Number(distance); if(!Number.isFinite(d)) throw Error('Distancia no válida');
    const out=[];
    for(let i=0;i<line.length;i++){
      const a=line[Math.max(0,i-1)], b=line[Math.min(line.length-1,i+1)];
      let dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy); if(!l) {out.push(line[i].slice());continue}
      const nx=-dy/l*side,ny=dx/l*side; out.push([line[i][0]+nx*d,line[i][1]+ny*d]);
    }
    return out;
  }
  function reverse(line){if(!valid(line))throw Error('Línea no válida');return line.slice().reverse().map(p=>p.slice())}
  function join(a,b,tolerance=1){if(!valid(a)||!valid(b))throw Error('Línea no válida');const ends=[[a.at(-1),b[0],true,false],[a[0],b.at(-1),false,true],[a[0],b[0],false,false],[a.at(-1),b.at(-1),true,true]];let best=null;for(const q of ends){const d=Math.hypot(q[0][0]-q[1][0],q[0][1]-q[1][1]);if(!best||d<best.d)best={q,d}}if(best.d>tolerance)throw Error('Los extremos están demasiado separados');const aa=best.q[2]?a.slice():a.slice().reverse(),bb=best.q[3]?b.slice().reverse():b.slice();return aa.concat(bb.slice(1))}
  function extendToNearest(line,targets,maxDistance=10){if(!valid(line)||!Array.isArray(targets)||!Number.isFinite(maxDistance)||maxDistance<0)throw Error('Geometría o distancia no válida');let best=null;for(const t of targets){if(!valid(t)||t===line)continue;for(const end of [0,line.length-1]){const p=line[end],adjacent=line[end===0?1:end-1],d0=[p[0]-adjacent[0],p[1]-adjacent[1]],len=Math.hypot(...d0);if(!len)continue;const ray=[d0[0]/len,d0[1]/len];for(let i=0;i<t.length-1;i++){const a=t[i],b=t[i+1],s=[b[0]-a[0],b[1]-a[1]],den=ray[0]*s[1]-ray[1]*s[0],ap=[a[0]-p[0],a[1]-p[1]];let q,d;if(Math.abs(den)>1e-12){const distance=(ap[0]*s[1]-ap[1]*s[0])/den,u=(ap[0]*ray[1]-ap[1]*ray[0])/den;if(distance< -1e-9||u< -1e-9||u>1+1e-9)continue;q=[p[0]+Math.max(0,distance)*ray[0],p[1]+Math.max(0,distance)*ray[1]];d=Math.max(0,distance)}else{const l2=ray[0]**2+ray[1]**2,ta=ap[0]*ray[0]+ap[1]*ray[1],tb=(b[0]-p[0])*ray[0]+(b[1]-p[1])*ray[1],lo=Math.min(ta,tb),hi=Math.max(ta,tb);if(Math.abs(ap[0]*ray[1]-ap[1]*ray[0])>1e-9||hi<0)continue;d=Math.max(0,lo);q=[p[0]+d*ray[0],p[1]+d*ray[1]]}if(d<=maxDistance&&(!best||d<best.d))best={d,end,point:q,targetIndex:targets.indexOf(t),segmentIndex:i}}}}if(!best)throw Error('Ningún tramo cruza la prolongación dentro de la distancia máxima');const out=line.map(p=>p.slice());out[best.end]=best.point.slice();return{line:out,distance:best.d,target:best.point.slice(),endIndex:best.end,targetIndex:best.targetIndex,segmentIndex:best.segmentIndex}}
  root.OcartoLineTools={parallel,reverse,join,extendToNearest};
  if(typeof module!=='undefined')module.exports=root.OcartoLineTools;
})(typeof window!=='undefined'?window:globalThis);
