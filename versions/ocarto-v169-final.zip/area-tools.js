/* Cierre controlado de pequeños huecos entre áreas; no fusiona símbolos distintos. */
(function(root){
  function ring(a){return Array.isArray(a)&&a.length>=3&&a.every(p=>Array.isArray(p)&&Number.isFinite(p[0])&&Number.isFinite(p[1]))}
  function bridge(a,b,maxDistance=10){if(!ring(a)||!ring(b))throw Error('Áreas no válidas');let best=null;for(let i=0;i<a.length;i++)for(let j=0;j<b.length;j++){const d=Math.hypot(a[i][0]-b[j][0],a[i][1]-b[j][1]);if(!best||d<best.d)best={i,j,d}}if(!best||best.d>maxDistance)throw Error('El hueco supera la distancia máxima');return{gap:best.d,connector:[a[best.i].slice(),b[best.j].slice()],indices:[best.i,best.j],review_required:true}}
  function cross(a,b,c){return(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])}
  function intersects(a,b,c,d){const eps=1e-10,ab1=cross(a,b,c),ab2=cross(a,b,d),cd1=cross(c,d,a),cd2=cross(c,d,b);return((ab1>eps&&ab2< -eps)||(ab1< -eps&&ab2>eps))&&((cd1>eps&&cd2< -eps)||(cd1< -eps&&cd2>eps))}
  function simpleQuad(q){if(q.length!==4)return false;for(let i=0;i<4;i++)for(let j=i+1;j<4;j++){if(j===i||j===(i+1)%4||i===(j+1)%4)continue;if(intersects(q[i],q[(i+1)%4],q[j],q[(j+1)%4]))return false}let area=0;for(let i=0;i<4;i++)area+=q[i][0]*q[(i+1)%4][1]-q[(i+1)%4][0]*q[i][1];return Math.abs(area)>1e-10}
  function bridgeArea(a,b,maxDistance=10){
    if(!ring(a)||!ring(b))throw Error('Áreas no válidas');
    let best=null;for(let i=0;i<a.length;i++)for(let j=0;j<b.length;j++){const d=Math.hypot(a[i][0]-b[j][0],a[i][1]-b[j][1]);if(!best||d<best.d)best={i,j,d}}
    const limit=Number(maxDistance);if(!Number.isFinite(limit)||limit<0)throw Error('Distancia máxima no válida');
    if(!best||best.d>limit)throw Error('El hueco supera la distancia máxima');
    if(best.d<=1e-10)throw Error('Las áreas ya se tocan; no hay hueco que cerrar');
    let choice=null;
    for(const ai of [(best.i+a.length-1)%a.length,(best.i+1)%a.length])for(const bj of [(best.j+b.length-1)%b.length,(best.j+1)%b.length]){
      const polygon=[a[best.i].slice(),a[ai].slice(),b[bj].slice(),b[best.j].slice()];
      if(!simpleQuad(polygon))continue;
      const score=Math.hypot(a[ai][0]-b[bj][0],a[ai][1]-b[bj][1]);
      if(!choice||score<choice.score)choice={polygon,score,ai,bj};
    }
    if(!choice)throw Error('No se puede crear un puente de área simple entre estos bordes');
    return{gap:best.d,connector:[a[best.i].slice(),b[best.j].slice()],polygon:choice.polygon,indices:[best.i,best.j],review_required:true};
  }
  function unionAdjacent(a,b,tolerance=1){if(!ring(a)||!ring(b))throw Error('Áreas no válidas');let best=null;for(let i=0;i<a.length;i++)for(let j=0;j<b.length;j++){const d=Math.hypot(a[i][0]-b[j][0],a[i][1]-b[j][1]);if(d<=tolerance&&(!best||d<best.d))best={i,j,d}}if(!best)throw Error('Las áreas no son contiguas');const rot=(p,k)=>p.slice(k).concat(p.slice(0,k));return rot(a,best.i).concat(rot(b,best.j).reverse().slice(1))}
  root.OcartoAreaTools={bridge,bridgeArea,unionAdjacent};if(typeof module!=='undefined')module.exports=root.OcartoAreaTools;
})(typeof window!=='undefined'?window:globalThis);
