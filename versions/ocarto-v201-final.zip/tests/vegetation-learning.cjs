const assert=require('node:assert/strict'),M=require('../vegetation-learning.js'),V=require('../vectorize-vegetation.js');
const cells=[];for(let i=0;i<14;i++)for(let j=0;j<10;j++){const tall=i<7,cover=tall?.72:.24,h=tall?11:2.6;cells.push({x:i+.5,y:j+.5,ground_points:5,vegetation_points:25,vegetation_return_fraction:cover,canopy_max_above_ground_m:h,canopy_mean_above_ground_m:h*.66,low_veg_points:tall?2:18,medium_veg_points:tall?3:4,high_veg_points:tall?20:3})}
const examples=[{label:'verde3',coordinates:[[[0,0],[4,0],[4,10],[0,10],[0,0]]]},{label:'blanco',coordinates:[[[9,0],[14,0],[14,10],[9,10],[9,0]]]}];
const model=M.train(cells,examples);assert.equal(model.labels.length,2);assert.equal(model.predict(cells[0]),'verde3');assert.equal(model.predict(cells.at(-1)),'blanco');assert.ok(M.labels.includes('frutales'),'fruit trees can be trained as a separate class');const fruitModel=M.train(cells,[{label:'frutales',coordinates:[[[0,0],[4,0],[4,10],[0,10],[0,0]]]}]);assert.equal(fruitModel.predict(cells[0]),'frutales');const fruitPolygons=V.vectorize(cells,1,{minArea:3,labeler:fruitModel.predict});assert.ok(fruitPolygons.features.some(f=>f.properties.category==='frutales'));assert.ok(M.labels.includes('rayado'),'striped low vegetation can be trained separately');const stripeModel=M.train(cells,[{label:'rayado',coordinates:[[[0,0],[4,0],[4,10],[0,10],[0,0]]]}]);assert.equal(stripeModel.predict(cells[0]),'rayado');
const conflictModel=M.train(cells,[examples[0],{label:'amarillo',coordinates:[[[0,0],[2,0],[2,10],[0,10],[0,0]]]}]);assert.ok(conflictModel.conflicts>0,'overlapping labels exclude ambiguous training cells');assert.deepEqual(conflictModel.conflictPairs,[{labels:['amarillo','verde3'],cells:20}],'the model reports the label pairs responsible for conflicts');
const saved=JSON.parse(JSON.stringify(model.toJSON())),restored=M.fromJSON(saved);assert.equal(restored.predict(cells[0]),model.predict(cells[0]));assert.equal(restored.predict(cells.at(-1)),model.predict(cells.at(-1)));assert.deepEqual(restored.labels,model.labels);assert.equal(saved.format,'ocarto-vegetation-model');
assert.throws(()=>M.fromJSON({...saved,version:99}),/inválido o incompatible/);
assert.throws(()=>M.fromJSON({...saved,featureNames:['X']}),/inválido o incompatible/);
assert.throws(()=>M.fromJSON({...saved,samples:[{label:'rojo',fp:[0,0,0,0,0,0]}]}),/inválido o incompatible|Muestra del modelo inválida/);
const fc=V.vectorize(cells,1,{minArea:3,labeler:model.predict});assert.ok(fc.features.some(f=>f.properties.category==='verde3'));assert.ok(fc.features.some(f=>f.properties.category==='blanco'));assert.ok(fc.features.every(f=>f.properties.review_required===true));
assert.throws(()=>M.train(cells,[]),/Muestras insuficientes/);
assert.throws(()=>M.train(cells,[{label:'rojo',coordinates:examples[0].coordinates}]),/no reconocida/);
assert.throws(()=>M.train(cells,[{label:'verde3',coordinates:[examples[0].coordinates[0],[[1,1],[2,1],[NaN,2]]]}]),/Polígono de aprendizaje inválido/);
assert.throws(()=>M.train(cells,[{label:'verde3',coordinates:[[[0,0],[4,0],[4,10],[0,10],[0,0]],[[1,1],[2,1]]]}]),/Polígono de aprendizaje inválido/);
assert.throws(()=>M.train(cells,[{label:'verde3',coordinates:[[...Array(250001)].map(()=>[0,0])]}]),/demasiado complejo/);
assert.equal(M.inPolygon(2,2,[[[0,0],[4,0],[4,4],[0,4]],[[1,1],[3,1],[3,3],[1,3]]]),false,'interior rings stay excluded');

const one=M.train(cells,[examples[0]]);assert.equal(one.predict(cells[0]),'verde3');assert.equal(one.predict(cells.at(-1)),null,'single class must not paint unrelated cells');
const manyGuideAreas=M.train(cells,Array.from({length:240},()=>examples[0]));assert.equal(manyGuideAreas.predict(cells[0]),'verde3','large OCAD guide layers are spatially indexed instead of rejected');assert.equal(manyGuideAreas.counts.verde3,40,'overlapping same-class guides do not multiply training cells');
assert.deepEqual(M.missingLabels(manyGuideAreas,[examples[0],examples[1],{label:'no-es-clase',coordinates:[]}]),['blanco'],'reports guide classes with no valid LiDAR training cells');
assert.deepEqual(M.fingerprint({ground_points:5,vegetation_points:0,canopy_max_above_ground_m:null,canopy_mean_above_ground_m:null,vegetation_return_fraction:0}),[0,0,0,0,0,0]);
console.log('✓ v25 aprendizaje LiDAR: etiquetas supervisadas, filtro de muestras, predicción conservadora y vectorización');
