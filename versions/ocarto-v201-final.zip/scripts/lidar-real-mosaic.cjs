'use strict';
const fs=require('node:fs');
const path=require('node:path');
const Vegetation=require('../vegetation-lidar.js');
const Learn=require('../vegetation-learning.js');
const SymbolGuides=require('../vegetation-symbol-guides.js');
const OcadObjects=require('../ocad-objects.js');
const Vector=require('../vectorize-vegetation.js');

function readHeader(buffer){
 if(buffer.byteLength<375)throw Error('Cabecera LAS/LAZ incompleta');
 const d=new DataView(buffer.buffer,buffer.byteOffset,buffer.byteLength);
 if(d.getUint32(0,true)!==0x4653414c)throw Error('Cabecera LAS inválida');
 const major=d.getUint8(24),minor=d.getUint8(25),format=d.getUint8(104)&63,compressed=!!(d.getUint8(104)&0xc0),recordLength=d.getUint16(105,true),offset=d.getUint32(96,true);
 let count=d.getUint32(107,true);if(major===1&&minor>=4){const extended=Number(d.getBigUint64(247,true));if(extended)count=extended}
 const min={0:20,1:28,2:26,3:34,4:57,5:63,6:30,7:36,8:38,9:59,10:67}[format];
 if(!compressed||!min||recordLength<min||!Number.isSafeInteger(count)||count<1)throw Error('Cada archivo debe ser un LAZ compatible');
 return{major,minor,format,count,recordLength,offset,scale:[131,139,147].map(p=>d.getFloat64(p,true)),origin:[155,163,171].map(p=>d.getFloat64(p,true))};
}
function collectOcadGuides(file){
 const parsed=OcadObjects.parseOcadObjects(fs.readFileSync(file));
 const features=parsed.objects.map(o=>({type:'area',symbolCode:o.symbolCode,points:o.geometry.coordinates[0].slice(0,-1).map(([x,y])=>({x,y})),holes:o.geometry.coordinates.slice(1).map(r=>r.slice(0,-1).map(([x,y])=>({x,y})))}));
 const guide=SymbolGuides.collect(features,{worldRing:ring=>ring.map(p=>[p.x,p.y])});
 if(!guide.polygons.length)throw Error('El OCAD no contiene áreas guía reconocidas de vegetación');
 return{parsed,guide};
}
async function main(){
 const args=process.argv.slice(2),cell=Number(args.at(-1))>=1?Number(args.pop()):5,mapFile=args.shift(),files=args;
 if(!mapFile||files.length<2){console.error('Uso: node scripts/lidar-real-mosaic.cjs <mapa.ocd> <tesela1.laz> <tesela2.laz> [...teselas.laz] [celda-m]');process.exitCode=2;return}
 if(!Number.isFinite(cell)||cell<1)throw Error('La celda de vegetación debe ser al menos 1 m');
 const map=collectOcadGuides(path.resolve(mapFile)),crs=map.parsed.setup.crs;
 if(!crs||!map.parsed.setup.georeferenced)throw Error('El mapa OCAD guía debe estar georreferenciado y declarar CRS');
 const factory=require('../vendor/laz-perf.js'),module=await factory({locateFile:name=>path.join(__dirname,'..','vendor',name)}),store=Vegetation.create(cell,{maxCells:100000}),classCounts={},fileResults=[];
 let totalPoints=0,started=Date.now();
 try{
  for(const inputFile of files){
   const resolved=path.resolve(inputFile);if(!fs.existsSync(resolved))throw Error(`No existe la tesela: ${resolved}`);
   const buffer=fs.readFileSync(resolved),meta=readHeader(buffer);
   if(meta.count<2_000_000)throw Error(`${path.basename(resolved)} declara menos de 2 millones de puntos`);
   const compressed=module._malloc(buffer.byteLength);if(!compressed)throw Error(`Memoria insuficiente para ${path.basename(resolved)}`);
   const record=module._malloc(meta.recordLength);if(!record){module._free(compressed);throw Error('Memoria insuficiente para el punto temporal')}
   let decoder=null;
   try{
    module.HEAPU8.set(buffer,compressed);decoder=new module.LASZip();decoder.open(compressed,buffer.byteLength);
    if(decoder.getCount()!==meta.count||decoder.getPointLength()!==meta.recordLength||decoder.getPointFormat()!==meta.format)throw Error(`La cabecera de ${path.basename(resolved)} no coincide con el decodificador`);
    const point=new DataView(module.HEAPU8.buffer,record,meta.recordLength);
    for(let i=0;i<meta.count;i++){
     decoder.getPoint(record);const x=point.getInt32(0,true)*meta.scale[0]+meta.origin[0],y=point.getInt32(4,true)*meta.scale[1]+meta.origin[1],z=point.getInt32(8,true)*meta.scale[2]+meta.origin[2],classification=point.getUint8(meta.format<=5?15:16),intensity=point.getUint16(12,true),returnNumber=point.getUint8(14)&15;
     classCounts[classification]=(classCounts[classification]||0)+1;store.add(x,y,z,classification,intensity,returnNumber);
    }
    totalPoints+=meta.count;fileResults.push({file:path.basename(resolved),points:meta.count,format:meta.format,lasVersion:`${meta.major}.${meta.minor}`});
   }finally{if(decoder)try{decoder.delete()}catch(_){}module._free(record);module._free(compressed)}
  }
  const rows=store.finish({includeGeoJSON:false}).rows,model=Learn.train(rows,map.guide.polygons),predicted=rows.filter(r=>model.predict(r)).length,candidates=Vector.vectorize(rows,cell,{minArea:100,minWidth:4,maxFeatures:10000,labeler:model.predict,includeUncertain:true});
  console.log(JSON.stringify({crs,cellSizeM:cell,files:fileResults,totalPoints,classificationCounts:classCounts,elapsedSeconds:+((Date.now()-started)/1000).toFixed(1),mosaicCells:rows.length,usableCells:rows.filter(r=>Learn.fingerprint(r)).length,ocad:{version:map.parsed.version,guideAreas:map.guide.matchedFeatures,guideCounts:map.guide.labelCounts},training:{labels:model.labels,trainingCells:model.counts,untrainedGuideLabels:Learn.missingLabels(model,map.guide.polygons),prototypes:model.prototypes,conflicts:model.conflicts,conflictPairs:model.conflictPairs,predictedCells:predicted,candidateAreas:candidates.features.length,candidateCells:candidates.properties.counts,reviewRequired:true,orthophotoRequired:false}},null,2));
 }finally{module.reset?.()}
}
main().catch(e=>{console.error(`Fallo del mosaico LiDAR real: ${e.message}`);process.exitCode=1});
