'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const match=html.match(/function applyVertexHistory\(direction\)\{[\s\S]*?\n  function renderVertexEditor\(/);
assert.ok(match,'vertex history implementation is present');
const source=match[0].replace(/\n  function renderVertexEditor\($/,'');
const HISTORY=Symbol('vertexHistoryId');
const before={type:'area',curve:'bezier',naturalCurve:'cubic-bezier',points:[{x:0,y:0,tangent:{x:2,y:1},outTangent:{x:1,y:2},id:'outer'}],holes:[[{x:3,y:3,inTangent:{x:-1,y:0},id:'hole'}]],custom:{keep:true}};
const after={type:'area',points:[{x:0,y:0,id:'outer'},{x:1,y:1}],holes:[[{x:3,y:3,id:'hole'}]],custom:{keep:true}};
const feature={...after};Object.defineProperty(feature,HISTORY,{value:7,configurable:true});
const history={undo:[{before:JSON.stringify(before),after:JSON.stringify(after)}],redo:[]};
const context={VERTEX_HISTORY_ID:HISTORY,S:{selection:{collection:'feature',index:0,vertexIndex:1},features:[feature],vertexHistory:new Map([[7,history]]),insertVertexMode:true,vertexSelectionMode:true,selectedVertices:[1]},renderVectorLayers(){},draw(){}};
const applyHistory=vm.runInNewContext(`(${source})`,context);
applyHistory('undo');
assert.deepEqual(JSON.parse(JSON.stringify(context.S.features[0])),before,'undo restores the full curve, handles, holes and metadata');
assert.equal(context.S.features[0][HISTORY],7,'undo carries history identity forward');
assert.equal(context.S.selection.vertexIndex,0,'undo clamps vertex selection to restored geometry');
assert.deepEqual(history.undo,[]);assert.equal(history.redo.length,1);
applyHistory('redo');
assert.deepEqual(JSON.parse(JSON.stringify(context.S.features[0])),after,'redo removes curve-only fields and restores the polyline snapshot exactly');
assert.deepEqual(history.redo,[]);assert.equal(history.undo.length,1);
// Regression guard for v196: generated vertices have geometry only, while
// original LiDAR and application metadata survive history round trips.
const originalWithMetadata={type:'line',curve:'bezier',points:[
  {x:0,y:0,id:'source-a',rawX:100,rawY:200,custom:{role:'source'},outTangent:{x:2,y:4}},
  {x:10,y:0,id:'source-b',rawX:110,rawY:200,custom:{role:'end'},inTangent:{x:-2,y:4}}
]};
const generatedPolyline={type:'line',points:[
  {x:0,y:0,id:'source-a',rawX:100,rawY:200,custom:{role:'source'},vertexType:'normal'},
  {x:5,y:3,vertexType:'normal'},
  {x:10,y:0,id:'source-b',rawX:110,rawY:200,custom:{role:'end'},vertexType:'normal'}
]};
const tracked={...generatedPolyline};Object.defineProperty(tracked,HISTORY,{value:8,configurable:true});
context.S.features=[tracked];context.S.selection={collection:'feature',index:0,vertexIndex:1};
const metadataHistory={undo:[{before:JSON.stringify(originalWithMetadata),after:JSON.stringify(generatedPolyline)}],redo:[]};
context.S.vertexHistory.set(8,metadataHistory);
applyHistory('undo');
assert.deepEqual(JSON.parse(JSON.stringify(context.S.features[0])),originalWithMetadata,'undo restores original source metadata and Bézier handles exactly');
applyHistory('redo');
assert.deepEqual(JSON.parse(JSON.stringify(context.S.features[0])),generatedPolyline,'redo restores geometry-only interpolated points without invented source metadata');
assert.equal(context.S.features[0].points[1].rawX,undefined);
console.log('✓ deshacer y rehacer restauran la geometría completa de vértices');
