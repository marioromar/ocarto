# Ocarto v1.103 (v203)

## Diagnóstico al reabrir proyectos

- Al abrir un proyecto con un modelo LiDAR guardado, el panel informa de las etiquetas y muestras restauradas, además de las celdas ambiguas y sus principales parejas.
- El diagnóstico persistido en v202 queda visible inmediatamente, sin necesidad de volver a ejecutar la predicción.
- Los proyectos sin modelo siguen abriéndose sin cambios.

## Verificación

- `npm test`: 66 pruebas.
- Comprobación sintáctica de los scripts JavaScript incrustados en la aplicación.
- Versión visible de la aplicación: v1.103.
