# Ocarto v1.109 (v209)

## Corrección de resolución en mosaicos LiDAR

- El mosaico de área conserva ahora la celda de vegetación elegida desde 0,1 m, en vez de elevarla silenciosamente a 1 m.
- La rejilla de terreno también aplica el mínimo declarado de 0,1 m.
- Se mantiene 0,5 m como valor inicial y 1 m como opción para áreas mayores.
- Se añade una prueba que protege la configuración submétrica en el flujo de mosaico.

## Verificación

- `npm test`: 66 pruebas.
- Prueba real en PNOA: el archivo completo contiene 10.852.474 puntos. Un recorte de 200 × 200 m a 0,5 m procesó 642.869 puntos interiores y produjo 103.714 celdas de terreno y 129.867 de vegetación.
- Versión visible: v1.109.
