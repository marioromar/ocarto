# Ocarto v1.98 — versión visible correcta

- Actualiza el título de la pestaña y el indicador de versión de la interfaz a v1.98.
- Añade una prueba para evitar que los archivos publicados sigan mostrando v1.68 o v1.61 mientras se trabaja sobre versiones posteriores.
- No modifica mapas, geometrías ni datos guardados.

## Verificación

- `npm test`: 66 pruebas.
- Chromium no está instalado, por lo que no se pudo ejecutar la comprobación visual de navegador.
