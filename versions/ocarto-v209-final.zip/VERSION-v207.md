# Ocarto v1.107 (v207)

## Rejillas LiDAR de 0,1 a 0,5 m

- Terreno y vegetación parten de 0,5 m y permiten bajar hasta 0,1 m en XY.
- Los proyectos guardan y restauran resoluciones submétricas, por ejemplo 0,25 m.
- Se conserva el límite de 500.000 celdas por rejilla; las resoluciones menores requieren recortar más el área para ajustarse a memoria y capacidad.
- LAS/LAZ sigue recorriéndose por lotes, sin un tope fijo de 2 millones de puntos; el tamaño de archivo y el número de celdas ocupadas determinan los recursos necesarios.

## Verificación

- `npm test`: 66 pruebas.
- Se comprueba la normalización del proyecto y el inicio de mosaico con celdas de 0,25 m.
- Versión visible: v1.107.
