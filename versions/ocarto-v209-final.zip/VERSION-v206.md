# Ocarto v1.106 (v206)

## Resolución de 0,5 m y mayor capacidad LiDAR

- La rejilla XY de terreno y la de vegetación parten ahora de 0,5 m y permiten esa resolución al guardar y restaurar un proyecto.
- Aumenta de 100.000 a 500.000 el límite de celdas de terreno y vegetación en nubes y mosaicos. A 0,5 m, 500.000 celdas representan aproximadamente 0,125 km² de cobertura cuadrada completa; el recorte por polígono permite concentrar el detalle.
- El acumulador de vegetación guarda estadísticas en columnas numéricas compactas, reduciendo el consumo de memoria por celda.
- LAS/LAZ sigue procesándose por lotes de 100.000 puntos; ese tamaño de lote no limita el total de puntos del archivo.

## Verificación

- `npm test`: 66 pruebas ejecutadas y aprobadas.
- Se comprueba la resolución de 0,5 m en ajustes de proyecto y mosaico.
- Versión visible de la aplicación: v1.106.
