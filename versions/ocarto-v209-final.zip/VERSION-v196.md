# Ocarto v1.96 — metadatos correctos en vértices Bézier nuevos

- Corrige la subdivisión adaptativa para que los puntos interpolados no hereden identificadores, coordenadas LiDAR ni metadatos personalizados del vértice vecino.
- Los vértices originales conservan sus coordenadas y atributos; los nuevos vértices reciben solo sus coordenadas geométricas y tipo normal.
- Añade pruebas para identificar metadatos falsos en puntos interpolados.

## Verificación

- `npm test`: 65 pruebas ejecutadas.
- Sintaxis de scripts inline y módulos Bézier comprobada.
