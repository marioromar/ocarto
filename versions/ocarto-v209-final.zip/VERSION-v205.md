# Ocarto v1.105 (v205)

## Coherencia del diagnóstico de solapes

- Al importar un modelo con diagnóstico por parejas, se comprueba que el desglose cubra al menos el total de celdas ambiguas registrado.
- Se mantiene la posibilidad de que una misma celda aparezca en varias parejas cuando se solapan más de dos etiquetas.
- Los modelos antiguos sin desglose detallado siguen siendo compatibles.
- Se añadió una prueba para detectar desgloses incompletos.

## Verificación

- `npm test`: 66 pruebas.
- `node --check vegetation-learning.js`.
- Versión visible de la aplicación: v1.105.
