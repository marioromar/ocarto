# Ocarto v1.108 (v208)

## Rejillas submétricas y pruebas de nubes grandes

- Terreno y vegetación parten de 0,5 m y permiten bajar hasta 0,1 m; 1 m también se puede elegir para áreas mayores.
- Los scripts de prueba LiDAR real aceptan esas mismas resoluciones submétricas.
- LAS/LAZ no tiene un tope fijo de 2 millones de puntos: se procesa por lotes de 100.000, aunque el archivo comprimido y las celdas ocupadas consumen memoria.
- Prueba real con una tesela PNOA: 10.852.474 puntos procesados en 7,9 s a 5 m, con 40.000 celdas de vegetación. Esta medición no significa que toda la tesela quepa en la rejilla de 0,5 m: el máximo de 500.000 celdas exige recortar a una zona menor para esa resolución.

## Verificación

- `npm test`: 66 pruebas.
- `node --check` en los scripts de flujo LiDAR real.
- Versión visible: v1.108.
