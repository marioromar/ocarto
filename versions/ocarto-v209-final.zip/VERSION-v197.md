# Ocarto v1.97 — historial de vértices y metadatos LiDAR

- Amplía la prueba del historial de edición para cubrir una conversión de Bézier a polilínea con vértices interpolados.
- Comprueba que Deshacer restaura identificadores, coordenadas LiDAR, metadatos personalizados y tiradores Bézier de los anclajes originales.
- Comprueba que Rehacer recupera los puntos interpolados solo con atributos geométricos, sin inventar coordenadas LiDAR ni metadatos de origen.
- No cambia el comportamiento de edición; añade una protección contra regresiones en guardado temporal de la edición e historial.

## Verificación

- `npm test`: 65 pruebas ejecutadas.
- Prueba de navegador omitida porque Chromium no está instalado.
