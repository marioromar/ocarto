# Ocarto v1.104 (v204)

## Validación del modelo de vegetación

- Al importar un modelo, se rechazan diagnósticos que repiten la misma pareja de etiquetas, aunque el orden de las etiquetas sea distinto.
- Se mantienen los límites de recuento por pareja y la compatibilidad con modelos anteriores que no guardaban este diagnóstico.
- Se añadió una prueba sintética para la pareja duplicada.

## Verificación

- `npm test`: 66 pruebas.
- Versión visible de la aplicación: v1.104.
