# Ocarto v1.99 — validación LiDAR real en Bobadilla

- Documenta pruebas reales con dos teselas PNOA LAS 1.4, formato de punto 8, de 10,85 y 11,30 millones de puntos.
- Confirma la ejecución del análisis LiDAR y el entrenamiento con un mapa guía OCAD 2018 en EPSG:32630, sin ortofoto.
- En la tesela que se solapa con el mapa se aprendieron cinco etiquetas y se generaron 1.680 áreas candidatas para revisión.
- Registra que dos etiquetas quedaron sin muestras suficientes y que 3.024 celdas tuvieron conflicto entre áreas guía; las propuestas siguen requiriendo revisión cartográfica.
- No cambia el algoritmo ni los proyectos existentes; añade evidencia reproducible en `README-LAZ.md`.

## Verificación

- `npm test`: ejecutar la suite sintética al publicar.
- Flujos reales: 10.852.474 y 11.295.695 puntos procesados; 8,1 s y 8,5 s de análisis LiDAR respectivamente en este entorno.
