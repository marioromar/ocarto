/* Adaptive cubic Bezier flattening for editable map geometry. */
(function(root){
  'use strict';
  function point(p){return{x:p.x,y:p.y}}
  function distanceToSegment(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(!l2)return Math.hypot(p.x-a.x,p.y-a.y);const t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/l2));return Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy)}
  function flattenRing(points,closed,tolerance,{maxDepth,maxPoints}){
    if(!Array.isArray(points)||points.length<(closed?3:2)||points.some(p=>!p||!Number.isFinite(p.x)||!Number.isFinite(p.y)))throw Error('Geometría Bézier no válida');
    const first={...points[0],...point(points[0])};delete first.tangent;delete first.inTangent;delete first.outTangent;const out=[first];let count=1;
    const append=(p,metadata)=>{if(++count>maxPoints)throw Error(`La curva supera el límite de ${maxPoints} vértices; aumenta la tolerancia`);out.push({...metadata,...point(p),vertexType:metadata?.vertexType||'normal'});delete out.at(-1).tangent;delete out.at(-1).inTangent;delete out.at(-1).outTangent};
    const segment=(a,b,depth,endMeta)=>{
      const dx=b.x-a.x,dy=b.y-a.y,av=a.vertexType==='corner'?{x:dx/3,y:dy/3}:a.outTangent||a.tangent||{x:dx/3,y:dy/3},iv=b.vertexType==='corner'?{x:-dx/3,y:-dy/3}:b.inTangent||(b.tangent?{x:-b.tangent.x,y:-b.tangent.y}:{x:-dx/3,y:-dy/3}),p0=point(a),p1={x:a.x+av.x,y:a.y+av.y},p2={x:b.x+iv.x,y:b.y+iv.y},p3=point(b),flat=Math.max(distanceToSegment(p1,p0,p3),distanceToSegment(p2,p0,p3));
      if(flat<=tolerance){append(p3,endMeta);return}
      if(depth>=maxDepth)throw Error('No se alcanza la tolerancia solicitada al convertir la curva');
      const mid=(p,q)=>({x:(p.x+q.x)/2,y:(p.y+q.y)/2}),q0=mid(p0,p1),q1=mid(p1,p2),q2=mid(p2,p3),r0=mid(q0,q1),r1=mid(q1,q2),m=mid(r0,r1);
      const leftA={...a,outTangent:{x:q0.x-p0.x,y:q0.y-p0.y}},leftB={...b,inTangent:{x:r0.x-m.x,y:r0.y-m.y}},rightA={...a,outTangent:{x:r1.x-m.x,y:r1.y-m.y}},rightB={...b,inTangent:{x:q2.x-p3.x,y:q2.y-p3.y}},midpoint={...point(m),inTangent:leftB.inTangent,outTangent:rightA.outTangent,vertexType:'normal'};
      segment(leftA,midpoint,depth+1,{vertexType:'normal'});
      segment(midpoint,rightB,depth+1,endMeta);
    };
    const n=closed?points.length:points.length-1;
    for(let i=0;i<n;i++)segment(points[i],points[(i+1)%points.length],0,points[(i+1)%points.length]);
    if(closed)out.pop();
    return out;
  }
  function flattenFeature(feature,tolerance,{maxDepth=16,maxPoints=20000,maxValidatedPoints=2400,simplifyTools=root.OcartoSimplifyTools}={}){
    if(!feature||feature.curve!=='bezier')throw Error('Selecciona una geometría Bézier');
    if(!Number.isFinite(tolerance)||tolerance<=0)throw Error('Tolerancia no válida');
    if(!Number.isInteger(maxDepth)||maxDepth<1||maxDepth>24||!Number.isInteger(maxPoints)||maxPoints<3)throw Error('Límites de conversión no válidos');
    if(!Number.isInteger(maxValidatedPoints)||maxValidatedPoints<3||maxValidatedPoints>2500)throw Error('Límite topológico no válido');
    const closed=feature.type==='area',budget=tolerance/2,points=flattenRing(feature.points,closed,budget,{maxDepth,maxPoints});let remaining=maxPoints-points.length,holes=[];
    if(closed)for(const ring of feature.holes||[]){const flat=flattenRing(ring,true,budget,{maxDepth,maxPoints:remaining});remaining-=flat.length;if(remaining<0)throw Error('La curva genera demasiados vértices para convertirla');holes.push(flat)}
    let total=points.length+holes.reduce((n,r)=>n+r.length,0),result={points,holes};
    if(total>maxValidatedPoints){
      if(!simplifyTools||typeof simplifyTools.simplify!=='function')throw Error('No se puede reducir la polilínea al límite topológico disponible');
      const reduce=ring=>simplifyTools.simplify(ring,budget,{closed});
      result={points:reduce(points),holes:holes.map(reduce)};total=result.points.length+result.holes.reduce((n,r)=>n+r.length,0);
      if(total>maxValidatedPoints)throw Error(`La curva necesita ${total} vértices para respetar la tolerancia; aumenta la tolerancia para validar el máximo de ${maxValidatedPoints}`);
    }
    return result;
  }
  root.OcartoBezierPolyline={flattenFeature};if(typeof module==='object'&&module.exports)module.exports=root.OcartoBezierPolyline;
})(typeof globalThis!=='undefined'?globalThis:this);
