# Ocarto v1.100 — comprobador real de mosaicos LiDAR

- Añade `npm run test:real-mosaic -- mapa.ocd tesela1.laz tesela2.laz [celda-m]` para reproducir la prueba con varios LAZ y un mapa guía OCAD.
- Decodifica las teselas una a una y acumula los indicadores en una retícula compartida, con límite de 100.000 celdas.
- Valida con dos teselas reales: 22.148.169 puntos, 80.000 celdas y 79.977 utilizables a 5 m.
- Con el mapa guía de Bobadilla, sin ortofoto, entrenó las siete etiquetas disponibles, clasificó 68.510 celdas y generó 3.591 áreas candidatas sujetas a revisión.
- Las 6.692 celdas en conflicto entre etiquetas se informan; no se aceptan propuestas automáticamente.

## Verificación

- `npm test`: 66 pruebas sintéticas aprobadas.
- `node --check scripts/lidar-real-mosaic.cjs`: sintaxis válida.
- Prueba real de mosaico completada en 25,8 s en este entorno. El tiempo depende del equipo y de los archivos.
