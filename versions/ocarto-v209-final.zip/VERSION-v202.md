# Ocarto v1.102 (v202)

## Persistencia del diagnóstico LiDAR

- El modelo de aprendizaje conserva el desglose de celdas ambiguas por pareja de etiquetas en su JSON.
- Al guardar y volver a abrir un proyecto, la interfaz puede mostrar de nuevo esas parejas y el GeoJSON sigue exportándolas en `properties.training.conflictPairs`.
- Los modelos antiguos sin este campo siguen siendo compatibles.
- Se añadió cobertura para la restauración y validación de esos datos.
- Las propuestas continúan requiriendo revisión humana; conservar el diagnóstico no aprueba elementos automáticamente.

## Verificación

- `npm test`: 66 pruebas.
- Comprobación de sintaxis de `vegetation-learning.js`.
- Versión visible de la aplicación: v1.102.
