# Ocarto v1.101 (v201)

## Diagnóstico de solapes en el aprendizaje LiDAR

- La interfaz muestra el total de celdas ambiguas y las tres parejas de etiquetas con más conflictos.
- El GeoJSON exportado guarda el desglose por parejas en `properties.training.conflictPairs` para facilitar la revisión.
- Se añadió una prueba sintética para verificar el recuento cuando áreas de etiquetas distintas se solapan.
- En la prueba real del mosaico Bobadilla, las principales parejas fueron amarillo/rayado (3.022 celdas), rayado/verde3 (2.396) y amarillo/verde3 (743).
- Estos conflictos indican que el centro de una celda LiDAR cae dentro de áreas guía con etiquetas diferentes. Los bordes pueden contribuir por el tamaño de celda de 5 m; conviene revisar los polígonos fuente.
- Las predicciones siguen siendo propuestas que requieren revisión humana; el diagnóstico no aprueba áreas automáticamente.

## Verificación

- Prueba sintética de `vegetation-learning`: correcta.
- Prueba de mosaico real LAZ + OCAD: 22.148.169 puntos y 80.000 celdas de mosaico; 79.977 celdas utilizables.
- La prueba real produjo 3.591 áreas candidatas y 11.467 celdas inciertas.
- Versión visible de la aplicación: v1.101.
