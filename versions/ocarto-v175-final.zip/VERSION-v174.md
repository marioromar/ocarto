# Ocarto v1.74 — corte dibujado de áreas

- «Cortar en 2» usa el trazo que se dibuja de borde a borde en lugar de elegir los vértices más cercanos y cerrar con una cuerda arbitraria.
- Acepta un único corte que atraviese el contorno exactamente dos veces; rechaza trazos exteriores, ambiguos o coincidentes con un tramo del borde.
- Valida el área de origen y las dos piezas resultantes antes de editar. Si alguna pieza es inválida, el mapa queda intacto.
- Conserva los metadatos de vértices existentes y proyecta correctamente los nuevos puntos de corte; selecciona ambas áreas para revisarlas.
- En líneas se conserva el flujo de eliminación del tramo entre los puntos inicial y final dibujados.
- El corte de áreas requiere un contorno recto y sin huecos.

## Verificación

- Pruebas de corte recto y quebrado, validez de las piezas, conservación de superficie y rechazo de trazos sin dos cruces o con más de dos cruces.
- `npm test`: 62 pruebas ejecutadas.
- Sintaxis de `split-tools.js` y del script de interfaz verificada.
- Prueba de navegador omitida porque el ejecutable Chromium de Playwright no está instalado.
