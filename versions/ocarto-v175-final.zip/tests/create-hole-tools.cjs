'use strict';
const assert = require('node:assert/strict');
require('../topology-tools.js');
const { validateHole } = require('../area-tools.js');

const outer = [[0, 0], [10, 0], [10, 10], [0, 10]];
const hole = [[2, 2], [4, 2], [4, 4], [2, 4]];
assert.deepEqual(validateHole(outer, [], hole), hole);
assert.throws(() => validateHole(outer, [], [[12, 2], [14, 2], [14, 4], [12, 4]]), /fuera/);
assert.throws(() => validateHole(outer, [], [[8, 2], [12, 2], [12, 4], [8, 4]]), /cruza o toca/);
assert.throws(() => validateHole(outer, [hole], [[3, 3], [5, 3], [5, 5], [3, 5]]), /agujeros 1 y 2/);
assert.throws(() => validateHole(outer, [], [[2, 2], [8, 8], [2, 8], [8, 2]]), /área nula|auto-intersección/);

console.log('✓ creación de agujeros: formato, contención, cruces y solapes validados');
