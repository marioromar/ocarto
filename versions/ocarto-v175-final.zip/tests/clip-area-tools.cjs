'use strict';
const assert = require('node:assert/strict');
const { clipAreaToArea } = require('../topology-tools.js');

const square = [[0, 0], [4, 0], [4, 4], [0, 4]];
const clipped = clipAreaToArea(square, [[2, 1], [5, 1], [5, 3], [2, 3]]);
assert.deepEqual(clipped, [[2, 1], [4, 1], [4, 3], [2, 3]]);

// The clip ring may be clockwise; the result remains the same.
assert.deepEqual(clipAreaToArea(square, [[2, 3], [5, 3], [5, 1], [2, 1]]), clipped);
assert.deepEqual(clipAreaToArea(square, [[5, 1], [7, 1], [7, 3], [5, 3]]), []);

assert.throws(() => clipAreaToArea([[0, 0], [4, 0], [2, 1], [4, 4], [0, 4]], square), /convexas/);
assert.throws(() => clipAreaToArea(square, [[0, 0], [4, 0], [2, 1], [4, 4], [0, 4]]), /convexas/);
assert.throws(() => clipAreaToArea([[0, 0], [4, 4], [0, 4], [4, 0]], square), /área nula|auto-intersección/);

console.log('✓ recorte seguro de áreas convexas');
