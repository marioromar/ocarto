# Ocarto v1.71 — recorte seguro de áreas convexas

- «Recortar área por área» requiere exactamente dos áreas editables; selecciones mixtas o bloqueadas se rechazan sin cambios.
- Solo admite polígonos rectos, simples y convexos sin huecos. La operación rechaza explícitamente contornos cóncavos, curvos o inválidos, que el algoritmo no puede representar con seguridad.
- El algoritmo normaliza el sentido del límite recortador y calcula correctamente los cruces de sus bordes.
- Calcula la intersección con los desplazamientos de ambos objetos, conserva los metadatos de vértices originales y selecciona el área resultante.
- Cuando no queda superficie, no modifica el mapa.

## Verificación

- Pruebas para recorte parcial, límite horario y antihorario, falta de intersección y rechazo de áreas cóncavas/autointersectadas.
- `npm test`: 61 pruebas ejecutadas.
- Prueba de navegador omitida porque el ejecutable Chromium de Playwright no está instalado.
