/* Cierre controlado de pequeños huecos entre áreas; no fusiona símbolos distintos. */
(function(root){
  function ring(a){return Array.isArray(a)&&a.length>=3&&a.every(p=>Array.isArray(p)&&Number.isFinite(p[0])&&Number.isFinite(p[1]))}
  function bridge(a,b,maxDistance=10){if(!ring(a)||!ring(b))throw Error('Áreas no válidas');let best=null;for(let i=0;i<a.length;i++)for(let j=0;j<b.length;j++){const d=Math.hypot(a[i][0]-b[j][0],a[i][1]-b[j][1]);if(!best||d<best.d)best={i,j,d}}if(!best||best.d>maxDistance)throw Error('El hueco supera la distancia máxima');return{gap:best.d,connector:[a[best.i].slice(),b[best.j].slice()],indices:[best.i,best.j],review_required:true}}
  function cross(a,b,c){return(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])}
  function intersects(a,b,c,d){const eps=1e-10,ab1=cross(a,b,c),ab2=cross(a,b,d),cd1=cross(c,d,a),cd2=cross(c,d,b);return((ab1>eps&&ab2< -eps)||(ab1< -eps&&ab2>eps))&&((cd1>eps&&cd2< -eps)||(cd1< -eps&&cd2>eps))}
  function simpleQuad(q){if(q.length!==4)return false;for(let i=0;i<4;i++)for(let j=i+1;j<4;j++){if(j===i||j===(i+1)%4||i===(j+1)%4)continue;if(intersects(q[i],q[(i+1)%4],q[j],q[(j+1)%4]))return false}let area=0;for(let i=0;i<4;i++)area+=q[i][0]*q[(i+1)%4][1]-q[(i+1)%4][0]*q[i][1];return Math.abs(area)>1e-10}
  function bridgeArea(a,b,maxDistance=10){
    if(!ring(a)||!ring(b))throw Error('Áreas no válidas');
    let best=null;for(let i=0;i<a.length;i++)for(let j=0;j<b.length;j++){const d=Math.hypot(a[i][0]-b[j][0],a[i][1]-b[j][1]);if(!best||d<best.d)best={i,j,d}}
    const limit=Number(maxDistance);if(!Number.isFinite(limit)||limit<0)throw Error('Distancia máxima no válida');
    if(!best||best.d>limit)throw Error('El hueco supera la distancia máxima');
    if(best.d<=1e-10)throw Error('Las áreas ya se tocan; no hay hueco que cerrar');
    let choice=null;
    for(const ai of [(best.i+a.length-1)%a.length,(best.i+1)%a.length])for(const bj of [(best.j+b.length-1)%b.length,(best.j+1)%b.length]){
      const polygon=[a[best.i].slice(),a[ai].slice(),b[bj].slice(),b[best.j].slice()];
      if(!simpleQuad(polygon))continue;
      const score=Math.hypot(a[ai][0]-b[bj][0],a[ai][1]-b[bj][1]);
      if(!choice||score<choice.score)choice={polygon,score,ai,bj};
    }
    if(!choice)throw Error('No se puede crear un puente de área simple entre estos bordes');
    return{gap:best.d,connector:[a[best.i].slice(),b[best.j].slice()],polygon:choice.polygon,indices:[best.i,best.j],review_required:true};
  }
  function signedArea(points){let area=0;for(let i=0;i<points.length;i++){const p=points[i],q=points[(i+1)%points.length];area+=p[0]*q[1]-q[0]*p[1]}return area/2}
  function pointOnSegment(p,a,b,eps){const dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<eps)return Math.hypot(p[0]-a[0],p[1]-a[1])<=eps;const crossValue=Math.abs(dx*(p[1]-a[1])-dy*(p[0]-a[0]))/length;if(crossValue>eps)return false;const dot=(p[0]-a[0])*dx+(p[1]-a[1])*dy;return dot>=-eps&&dot<=dx*dx+dy*dy+eps}
  function validateRing(points,eps){if(!ring(points)||points.length<3)throw Error('Áreas no válidas');for(let i=0;i<points.length;i++)for(let j=i+1;j<points.length;j++){if(j===i||j===(i+1)%points.length||i===(j+1)%points.length)continue;if(intersects(points[i],points[(i+1)%points.length],points[j],points[(j+1)%points.length]))throw Error('Hay áreas con contornos cruzados')}if(Math.abs(signedArea(points))<=eps*eps)throw Error('Área degenerada')}
  function unionAdjacent(a,b,tolerance=1){
    const tol=Number(tolerance);if(!Number.isFinite(tol)||tol<0)throw Error('Tolerancia no válida');const eps=Math.max(1e-9,Math.min(tol,1e-5));
    validateRing(a,eps);validateRing(b,eps);
    const rings=[a.map(p=>p.slice()),b.map(p=>p.slice())].map(r=>signedArea(r)<0?r.reverse():r);
    const allVertices=rings.flat(),edges=[];
    for(let ringIndex=0;ringIndex<rings.length;ringIndex++){
      const points=rings[ringIndex];
      for(let i=0;i<points.length;i++){
        const start=points[i],end=points[(i+1)%points.length],dx=end[0]-start[0],dy=end[1]-start[1],length2=dx*dx+dy*dy;
        if(length2<=eps*eps)throw Error('Hay vértices duplicados en el contorno');
        const splits=[{t:0,p:start},{t:1,p:end}];
        for(const p of allVertices){if(p===start||p===end||!pointOnSegment(p,start,end,eps))continue;const t=((p[0]-start[0])*dx+(p[1]-start[1])*dy)/length2;if(t>eps&&t<1-eps)splits.push({t,p})}
        splits.sort((x,y)=>x.t-y.t);
        for(let j=1;j<splits.length;j++){const p=splits[j-1].p,q=splits[j].p;if(Math.hypot(q[0]-p[0],q[1]-p[1])>eps)edges.push({a:p.slice(),b:q.slice(),ringIndex})}
      }
    }
    const removed=new Set();let shared=0;
    for(let i=0;i<edges.length;i++){if(removed.has(i))continue;for(let j=i+1;j<edges.length;j++){if(removed.has(j)||edges[i].ringIndex===edges[j].ringIndex)continue;const x=edges[i],y=edges[j],reverse=Math.hypot(x.a[0]-y.b[0],x.a[1]-y.b[1])<=eps&&Math.hypot(x.b[0]-y.a[0],x.b[1]-y.a[1])<=eps,same=Math.hypot(x.a[0]-y.a[0],x.a[1]-y.a[1])<=eps&&Math.hypot(x.b[0]-y.b[0],x.b[1]-y.b[1])<=eps;if(reverse){removed.add(i);removed.add(j);shared++;break}if(same)throw Error('Las áreas se solapan y no se pueden unir con seguridad')}}
    if(!shared)throw Error('Las áreas deben compartir al menos un borde');
    const boundary=edges.filter((_,i)=>!removed.has(i));if(boundary.length<3)throw Error('La unión no forma un contorno válido');
    const key=p=>`${Math.round(p[0]/eps)},${Math.round(p[1]/eps)}`,outgoing=new Map();
    boundary.forEach((edge,i)=>{const k=key(edge.a);if(!outgoing.has(k))outgoing.set(k,[]);outgoing.get(k).push(i)});
    if([...outgoing.values()].some(list=>list.length!==1))throw Error('Las áreas solo se tocan en un punto o forman una unión ambigua');
    const unused=new Set(boundary.map((_,i)=>i)),loops=[];
    while(unused.size){const first=unused.values().next().value,loop=[],start=key(boundary[first].a);let current=first,guard=0,closed=false;while(current!==undefined&&unused.has(current)&&guard++<=boundary.length+1){const edge=boundary[current];unused.delete(current);loop.push(edge.a.slice());const nextKey=key(edge.b);if(nextKey===start){closed=true;break}const candidates=outgoing.get(nextKey)||[];current=candidates.find(index=>unused.has(index))}if(!closed)throw Error('No se pudo cerrar el contorno unido');loops.push(loop)}
    if(loops.length!==1)throw Error('La unión produciría varios contornos');
    const result=loops[0];validateRing(result,eps);return result;
  }
  function validateHole(outer,holes,candidate){
    if(!root.OcartoTopologyTools?.validatePolygon)throw Error('Validador topológico no disponible');
    if(!Array.isArray(holes)||!Array.isArray(candidate))throw Error('Anillo interior no válido');
    const result=root.OcartoTopologyTools.validatePolygon(outer,[...holes,candidate]);
    if(!result.valid)throw Error(result.issues.join('; '));
    return candidate.map(p=>p.slice());
  }
  root.OcartoAreaTools={bridge,bridgeArea,unionAdjacent,validateHole};if(typeof module!=='undefined')module.exports=root.OcartoAreaTools;
})(typeof window!=='undefined'?window:globalThis);
