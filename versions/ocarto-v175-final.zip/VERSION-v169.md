# Ocarto v1.69 — cerrar huecos con un área válida

- «Cerrar hueco entre áreas» ahora crea un polígono puente de cuatro vértices siguiendo los bordes cercanos de ambas áreas.
- La versión anterior creaba un área con solo dos puntos, una geometría degenerada que no podía rellenar el hueco correctamente.
- Rechaza áreas que ya se tocan, distancias fuera del límite y puentes que producirían un cuadrilátero degenerado o cruzado.
- Conserva intactas las áreas originales y marca el puente como pendiente de revisión; hay que comprobar su forma y símbolo antes de exportar.

## Verificación

- Prueba unitaria: puente rectangular válido, entradas intactas, áreas contiguas y distancia máxima.
- `npm test`: 60 pruebas superadas.
