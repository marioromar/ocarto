# Ocarto v1.70 — unión segura de áreas adyacentes

- «Unir áreas» elimina los tramos de borde compartidos y recorre el contorno exterior resultante; ya no concatena anillos completos, que podía producir autointersecciones y vértices repetidos.
- Admite bordes compartidos con vértices intermedios y normaliza el sentido de recorrido.
- Rechaza áreas solapadas, contactos en un solo punto, uniones ambiguas, curvas Bézier y áreas con huecos.
- Solo procesa una selección compuesta íntegramente por áreas editables del mismo símbolo y capa. Así no borra accidentalmente líneas o puntos que también estuvieran seleccionados.
- Conserva el desplazamiento del objeto y la metadata de vértices existentes, incluidas esquinas; la unión queda seleccionada y se puede deshacer.

## Verificación

- Pruebas de unión rectangular, borde compartido subdividido, superficie, entradas intactas, solape y contacto en un punto.
- `npm test`: 60 pruebas ejecutadas.
