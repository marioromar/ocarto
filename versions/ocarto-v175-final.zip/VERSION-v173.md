# Ocarto v1.73 — ajuste seguro de bordes

- «Ajustar bordes» requiere exactamente dos áreas distintas y editables: la primera seleccionada es la que se ajusta a la segunda.
- Rechaza selecciones mixtas, duplicadas, bloqueadas, protegidas y áreas con huecos.
- Calcula el ajuste sobre segmentos rectos o curvas Bézier, teniendo en cuenta el desplazamiento de ambos objetos y conservando la metadata de los vértices.
- Comprueba el contorno resultante antes de modificar el mapa. Si el ajuste genera autointersecciones o un polígono inválido, no cambia el área.
- Los vértices fuera de la tolerancia quedan intactos; la edición se puede deshacer.

## Verificación

- `npm test`: 62 pruebas ejecutadas, incluidas pruebas de ajuste a segmentos rectos y Bézier, offsets, precisión y metadatos.
- Sintaxis de `topology-tools.js` y del script de interfaz verificada.
- Prueba de navegador omitida porque el ejecutable Chromium de Playwright no está instalado.
