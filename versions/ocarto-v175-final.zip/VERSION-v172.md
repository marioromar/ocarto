# Ocarto v1.72 — creación validada de agujeros

- «Crear agujero en área» almacena los vértices como puntos cartográficos; antes guardaba pares numéricos incompatibles con el modelo del mapa.
- El trazo debe cerrarse cerca del inicio. Se captura el punto final para no depender de que el último evento de movimiento llegue antes de soltar.
- Valida el polígono completo antes de modificarlo: rechaza anillos fuera del contorno, cruces con el borde, autointersecciones y solapes con agujeros existentes.
- Solo admite áreas rectas y editables. Conserva los huecos existentes, registra el cambio para deshacer y permite cancelar el dibujo.

## Verificación

- Pruebas de contención válida, anillo exterior, cruce con borde, solape y autointersección.
- `npm test`: 62 pruebas ejecutadas.
- Prueba de navegador omitida porque el ejecutable Chromium de Playwright no está instalado.
