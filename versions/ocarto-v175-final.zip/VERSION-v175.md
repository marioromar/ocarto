# Ocarto v1.75 — recorte completo de líneas por áreas

- El recorte calcula las intersecciones entre cada tramo de línea y el contorno; ya no descarta vértices interiores ni omite las intersecciones de entrada y salida.
- Admite áreas cóncavas y huecos; devuelve todos los tramos interiores, incluso si la línea entra varias veces en el área.
- Conserva los vértices originales que permanecen, calcula coordenadas para los nuevos extremos y tiene en cuenta desplazamientos de objetos.
- Exige seleccionar exactamente una línea y un área editables. Conserva el área y selecciona todos los tramos recortados.
- Se limita a geometrías rectas; las curvas Bézier se rechazan para evitar convertirlas silenciosamente en polilíneas.

## Verificación

- Pruebas de intersecciones exactas, huecos, contornos cóncavos, orientación inversa, bordes coincidentes y geometría inválida.
- `npm test`: 62 pruebas ejecutadas.
- Sintaxis de `topology-tools.js` y del script de interfaz verificada.
- Prueba de navegador omitida porque el ejecutable Chromium de Playwright no está instalado.
