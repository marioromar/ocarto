(function(root){
  function split(path,index){
    if(!Array.isArray(path)||path.length<3||index<=0||index>=path.length-1)throw Error('El punto de corte debe estar dentro de la línea');
    return [path.slice(0,index+1),path.slice(index)];
  }
  function splitArea(path,a,b){
    if(!Array.isArray(path)||path.length<4)throw Error('El área no tiene suficientes vértices');
    const n=path.length;if(a===b||a<0||b<0||a>=n||b>=n)throw Error('Índices de corte no válidos');
    const walk=(from,to)=>{const out=[path[from]];let i=from;while(i!==to){i=(i+1)%n;out.push(path[i])}return out};
    const p=walk(a,b),q=walk(b,a);if(p.length<3||q.length<3)throw Error('El corte debe formar dos áreas');return [p,q];
  }
  function splitAreaByLine(path,cut){
    const topo=root.OcartoTopologyTools;if(!topo?.validatePolygon)throw Error('Validador topológico no disponible');
    if(!Array.isArray(path)||path.length<3||path.some(p=>!Array.isArray(p)||p.length<2||!p.every(Number.isFinite)))throw Error('El área no es válida');
    if(!Array.isArray(cut)||cut.length<2||cut.length>2500||cut.some(p=>!Array.isArray(p)||p.length<2||!p.every(Number.isFinite)))throw Error('El trazo de corte no es válido');
    const source=topo.validatePolygon(path);if(!source.valid)throw Error(`El área de origen no es válida: ${source.issues[0]}`);
    const scale=path.flat().reduce((m,v)=>Math.max(m,Math.abs(v)),1),eps=scale*1e-10,paramEps=1e-10,cross=(a,b)=>a[0]*b[1]-a[1]*b[0],sub=(a,b)=>[a[0]-b[0],a[1]-b[1]],hits=[];
    for(let i=0;i<cut.length-1;i++){
      const p=cut[i],q=cut[i+1],r=sub(q,p);if(Math.hypot(...r)<=eps)continue;
      for(let j=0;j<path.length;j++){
        const a=path[j],b=path[(j+1)%path.length],s=sub(b,a),den=cross(r,s),ap=sub(a,p);
        if(Math.abs(den)<=eps*eps){if(Math.abs(cross(ap,r))<=eps*Math.max(Math.hypot(...r),1))throw Error('El trazo coincide con un tramo del contorno y el corte es ambiguo');continue}
        const t=cross(ap,s)/den,u=cross(ap,r)/den;if(t< -paramEps||t>1+paramEps||u< -paramEps||u>1+paramEps)continue;
        const tc=Math.max(0,Math.min(1,t)),uc=Math.max(0,Math.min(1,u)),atStart=uc<=paramEps,atEnd=uc>=1-paramEps,point=atStart?a.slice():atEnd?b.slice():[p[0]+tc*r[0],p[1]+tc*r[1]],ringPos=atStart?j:atEnd?(j+1)%path.length:j+uc,cutPos=i+tc;
        if(!hits.some(h=>Math.hypot(h.point[0]-point[0],h.point[1]-point[1])<=eps))hits.push({point,ringPos,cutPos});
      }
    }
    if(hits.length!==2)throw Error('El trazo debe atravesar el contorno exactamente dos veces');
    hits.sort((a,b)=>a.cutPos-b.cutPos);const [first,last]=hits;
    const cutBetween=[first.point,...cut.slice(1).map((p,i)=>({p,pos:i+1})).filter(x=>x.pos>first.cutPos+paramEps&&x.pos<last.cutPos-paramEps).map(x=>x.p),last.point];
    const boundary=(start,end)=>{let from=start.ringPos,to=end.ringPos;if(to<=from)to+=path.length;const out=[start.point];for(let k=Math.floor(from)+1;k<to-paramEps;k++)out.push(path[k%path.length].slice());out.push(end.point);return out};
    const one=boundary(first,last),two=boundary(last,first),inside=cutBetween.slice(1,-1);
    const parts=[one.concat(inside.slice().reverse()),two.concat(inside)];
    for(const part of parts){if(part.length<3)throw Error('El corte no forma dos áreas');const checked=topo.validatePolygon(part);if(!checked.valid)throw Error(`El corte produciría un área inválida: ${checked.issues[0]}`)}
    return parts;
  }
  function cutLine(path,a,b){
    if(!Array.isArray(path)||path.length<3)throw Error('La línea no tiene suficientes vértices');
    if(!Number.isInteger(a)||!Number.isInteger(b)||a<0||b<0||a>=path.length||b>=path.length||a===b)throw Error('Índices de corte no válidos');
    const lo=Math.min(a,b),hi=Math.max(a,b),left=path.slice(0,lo+1),right=path.slice(hi);if(left.length<2||right.length<2)throw Error('El tramo debe quedar entre dos extremos');return [left,right];
  }
  const api={split,splitArea,splitAreaByLine,cutLine};
  root.OcartoSplitTools=api;
  if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
