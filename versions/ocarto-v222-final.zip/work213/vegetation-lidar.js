/* Ocarto v23. Derived per-cell LiDAR vegetation descriptors.
   Ground-relative canopy proxy, point distribution and intensity; NOT passability labels.
   Typed columns keep large grids compact while the string-key index handles sparse/global coordinates. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.OcartoVegetation=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const MAX_CELLS=1000000;
function create(cell,opts={}){
 cell=Number(cell);const maxCells=opts.maxCells===undefined?MAX_CELLS:Number(opts.maxCells);
 if(!Number.isFinite(cell)||cell<=0||!Number.isInteger(maxCells)||maxCells<1||maxCells>MAX_CELLS)throw Error('Tamaño de celda o límite de memoria inválido');
 const bins=new Map(),columns={i:new Float64Array(0),j:new Float64Array(0),ground:new Uint32Array(0),groundMin:new Float64Array(0),vegetation:new Uint32Array(0),vegMax:new Float64Array(0),vegSum:new Float64Array(0),intensitySum:new Float64Array(0),firstReturns:new Uint32Array(0),low:new Uint32Array(0),medium:new Uint32Array(0),high:new Uint32Array(0),building:new Uint32Array(0),roofMin:new Float64Array(0),roofMax:new Float64Array(0),wire:new Uint32Array(0),tower:new Uint32Array(0)};
 let used=0,capacity=0,processed=0;
 function reserve(required){if(required<=capacity)return;const next=Math.min(maxCells,Math.max(required,capacity?capacity*2:1024));for(const key of Object.keys(columns)){const old=columns[key],grown=new old.constructor(next);grown.set(old);columns[key]=grown}capacity=next}
 const add=(x,y,z,code,intensity=0,returnNumber=0)=>{
  if(![x,y,z,intensity,returnNumber].every(Number.isFinite))throw Error('Punto LiDAR no finito');
  if(![2,3,4,5,6,14,15].includes(code))return;
  const i=Math.floor(x/cell),j=Math.floor(y/cell),key=i+','+j;let at=bins.get(key);
  if(at===undefined){if(used>=maxCells)throw Error('Demasiadas celdas de vegetación: aumenta el tamaño de celda');reserve(used+1);at=used++;bins.set(key,at);columns.i[at]=i;columns.j[at]=j;columns.groundMin[at]=Infinity;columns.vegMax[at]=-Infinity;columns.roofMin[at]=Infinity;columns.roofMax[at]=-Infinity}
  processed++;
  if(code===2){columns.ground[at]++;if(z<columns.groundMin[at])columns.groundMin[at]=z}
  else if(code===6){columns.building[at]++;if(z<columns.roofMin[at])columns.roofMin[at]=z;if(z>columns.roofMax[at])columns.roofMax[at]=z}
  else if(code===14)columns.wire[at]++;
  else if(code===15)columns.tower[at]++;
  else{columns.vegetation[at]++;if(z>columns.vegMax[at])columns.vegMax[at]=z;columns.vegSum[at]+=z;columns.intensitySum[at]+=intensity;if(code===3)columns.low[at]++;else if(code===4)columns.medium[at]++;else columns.high[at]++;if(returnNumber===1)columns.firstReturns[at]++}
 };
 const finish=({includeGeoJSON=true}={})=>{
  if(typeof includeGeoJSON!=='boolean')throw Error('Opción GeoJSON inválida');
  const order=Array.from({length:used},(_,i)=>i);order.sort((a,b)=>columns.j[a]-columns.j[b]||columns.i[a]-columns.i[b]);
  const rows=[],features=[];
  for(const at of order){const i=columns.i[at],j=columns.j[at],ground=columns.ground[at],vegetation=columns.vegetation[at],building=columns.building[at],hasGround=ground>0,hasVeg=vegetation>0,usable=hasGround&&hasVeg;
   const total=ground+vegetation,cover=total?vegetation/total:0,h=usable?Math.max(0,columns.vegMax[at]-columns.groundMin[at]):null,meanH=usable?Math.max(0,columns.vegSum[at]/vegetation-columns.groundMin[at]):null;
   // Return fractions and intensity depend on capture settings; NOT calibrated runnability.
   const status=!hasGround?'sin-suelo-local':!hasVeg?'sin-vegetacion-clasificada':ground<3||vegetation<5?'muestra-reducida':'estimacion-observada';
   const properties={kind:'indicadores-vegetacion-lidar',ground_points:ground,vegetation_points:vegetation,ground_z_min:hasGround?+columns.groundMin[at].toFixed(3):null,canopy_max_above_ground_m:h===null?null:+h.toFixed(3),canopy_mean_above_ground_m:meanH===null?null:+meanH.toFixed(3),vegetation_return_fraction:+cover.toFixed(4),first_vegetation_returns:columns.firstReturns[at],mean_vegetation_intensity:hasVeg?+(columns.intensitySum[at]/vegetation).toFixed(2):null,low_veg_points:columns.low[at],medium_veg_points:columns.medium[at],high_veg_points:columns.high[at],building_points:building,building_roof_range_m:building?+(columns.roofMax[at]-columns.roofMin[at]).toFixed(3):null,building_height_above_ground_m:hasGround&&building?+Math.max(0,columns.roofMax[at]-columns.groundMin[at]).toFixed(3):null,wire_points:columns.wire[at],tower_points:columns.tower[at],quality:status,map_color:null,passability:null,review_required:true,warning:'Altura y densidad LiDAR no equivalen a penetrabilidad. Intensidad no comparable entre vuelos sin calibrar.'};
   const x=(i+.5)*cell,y=(j+.5)*cell;rows.push({x,y,...properties});
   if(includeGeoJSON&&usable)features.push({type:'Feature',properties,geometry:{type:'Polygon',coordinates:[[[i*cell,j*cell],[(i+1)*cell,j*cell],[(i+1)*cell,(j+1)*cell],[i*cell,(j+1)*cell],[i*cell,j*cell]]]}});
  }
  const result={cellSize:cell,cells:used,processed,quality:'Indicadores no calibrados; requieren cartografía de entrenamiento.',rows};
  if(includeGeoJSON)result.geojson={type:'FeatureCollection',name:'Ocarto v23 indicadores de vegetacion',properties:{cellSize:cell,nonAutomatic:true},features};
  return result;
 };
 return {add,finish,size:()=>used};
}
return {create,MAX_CELLS};
});
