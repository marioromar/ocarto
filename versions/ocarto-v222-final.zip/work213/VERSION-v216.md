# Ocarto v1.116 (v216)

## Feature Map opcional del relieve LiDAR

- Añadida la exportación desde la rejilla de suelo LiDAR como imagen opcional de fondo.
- Modos disponibles: sombreado multidireccional, pendiente en escala de grises y relieve local.
- Exporta PNG, PGW y PRJ dentro de ZIP, con extensión, tamaño de celda, CRS y método en metadatos.
- Mantiene transparentes las celdas sin datos y limita el tamaño del raster.
- Admite la rejilla generada con una nube LAS/LAZ o con un mosaico de teselas.

## Verificación

- Pruebas específicas para los tres modos, georreferenciación, celdas vacías y límites.
- Ejecutar `npm test` para la batería completa.
