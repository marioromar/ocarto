# Ocarto v1.117 (v217)

## Mapa raster de rugosidad LiDAR

- Añadida una exportación opcional desde el MDT de suelo con ventanas configurables de 3×3, 5×5 o 7×7 celdas.
- La métrica ajusta y descuenta el plano de inclinación local; representa el RMS de los residuos de altura para resaltar microrelieve sin confundir directamente pendiente con rugosidad.
- Exporta PNG, PGW y PRJ, más leyenda y metadatos de CRS, celda, ventana y contraste usado.
- Las celdas sin datos se mantienen transparentes y el raster de salida se limita a 1 000 000 de celdas para mantener acotado el cálculo. La imagen se marca como ayuda de interpretación: no clasifica rocas ni calcula transitabilidad.

## Verificación

- Pruebas para que una pendiente planar resulte lisa, un relieve localizado destaque y los parámetros/límites sean válidos.
- Ejecutar `npm test` para la batería completa.
