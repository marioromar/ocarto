# Hoja de ruta LiDAR para cartografía de orientación

## Criterios acordados

- **Feature Map de relieve (opcional):** producir imágenes georreferenciadas para usar como fondo cuando ayuden a interpretar el terreno. Prioridad de visualización: relieve sombreado multidireccional, pendiente y relieve local. El usuario decide si las genera y añade al mapa.
- **Rugosidad del terreno:** sí. Crear una capa raster configurable que resalte microrelieve y superficies ásperas. El resultado es una pista para revisar, no una clasificación automática de rocas ni de transitabilidad.
- **Estructura de vegetación:** sí. Combinar altura y densidad de retornos para mostrar claros, arbolado disperso, matorral y vegetación más densa. Las clases, umbrales y colores deben poder revisarse y ajustarse con ejemplos locales.
- **Árboles individuales:** sí. Detectar copas y generar objetos punto en el mapa con símbolos de orientación adecuados, asignables desde el catálogo o una plantilla OCAD. Conservar posición y, cuando la nube lo permita, altura y tamaño estimado de copa.
- **Elementos del terreno:** sí. Proponer cortados, rocas, taludes, muros, depresiones, vaguadas y otros elementos reconocibles como objetos cartográficos con simbología de orientación. Las líneas y áreas deben quedar editables en CART; los símbolos definitivos se asignan según el mapa destino.

## Secuencia de trabajo

1. **Completado en v1.116:** imágenes opcionales de sombreado multidireccional, pendiente y relieve local a partir del MDT, con exportación georreferenciada. La resolución usa el tamaño de celda configurado al preparar el terreno.
2. **Completado en v1.117:** raster de rugosidad con ventana configurable a partir del MDT; quita la tendencia de pendiente y deja visibles la resolución y el contraste.
3. **Primera entrega en v1.118:** se pueden añadir a CART clases preliminares por altura y densidad, conservando métricas y revisión. Queda pendiente completar la calibración por ejemplos y unificar salidas raster/vectoriales.
4. **Primera entrega en v1.119:** máximos locales de copa como puntos CART; árboles pequeños (418) y grandes (417), con revisión y umbrales configurables.
5. **v1.120:** rocas, muros/escarpes y ejes de vaguadas se incorporan directamente a CART en capas revisables, con símbolos provisionales 204/205, 513 y 305. **v1.121:** edificios, tendidos y apoyos clasificados LAS se añaden igualmente a CART; códigos 521 y 510 para edificios/tendidos, y símbolo pendiente de asignar para apoyos. Falta validar estos candidatos en zonas reales y ampliar el catálogo para escarpes/depresiones.
6. Conservar geometrías, atributos LiDAR y estado de revisión en CART; permitir exportar a OCAD usando la plantilla y sus símbolos.

## Reglas de calidad

- Ningún resultado LiDAR se incorpora silenciosamente como cartografía definitiva: debe poder previsualizarse, corregirse y aceptarse por el usuario.
- No asignar una clase de transitabilidad solo por altura o rugosidad. Presentar medidas y confianza como orientación para el cartógrafo.
- Respetar huecos y zonas sin datos; indicar cuándo la densidad, clasificación o fecha del vuelo no bastan para una detección fiable.
- Guardar procedencia, parámetros, resolución, CRS y métricas disponibles junto a cada raster u objeto.
- Mantener CART como proyecto principal. OCAD/OMAP son salidas de conversión; DXF queda secundario.

## Estado en Ocarto v1.121

Ya hay generación de Feature Map de vegetación, altura vectorial, clases estructurales preliminares incorporables a CART, imágenes de relieve del MDT, rugosidad del suelo y detectores preliminares de rocas, muros/escarpes, vaguadas y elementos artificiales. La calibración completa de la vegetación y la validación de símbolos de terreno en datos reales siguen pendientes. Los árboles (417/418), rocas (204/205), muros/escarpes (513), vaguadas (305), edificios (521) y tendidos (510) ya pueden añadirse como capas CART revisables; los apoyos eléctricos siguen sin código OCAD/ISOM confirmado.
