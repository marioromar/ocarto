# Ocarto v1.115 (v215)

## Conversión desde CART a OMAP y OCAD

- CART se mantiene como formato principal de proyecto editable.
- Añadida la acción «CART → OMAP» para convertir el mapa activo a OMAP nativo de OpenOrienteering Mapper.
- Añadida la conversión a OCAD 12/2018 a partir de una plantilla `.ocd` georreferenciada. Permite elegir símbolos del mapa destino para las cuatro bandas de altura, otras áreas y líneas, conservando la plantilla y su simbología.
- Se exportan geometrías lineales y áreas; las áreas con huecos y los tipos no compatibles se notifican/omiten para no cambiar su topología. Se exige EPSG coincidente.
- DXF permanece disponible como formato secundario en las herramientas de exportación existentes.

## Verificación

- Prueba específica del escritor OCAD: objetos añadidos, plantilla no modificada, símbolos validados y áreas con huecos omitidas.
- Ejecutar `npm test` para la batería completa.
