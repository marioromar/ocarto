# Ocarto v1.118 (v218)

## Vegetación estructurada en el proyecto CART

- «Añadir vegetación estructurada al mapa CART» ya funciona sin exigir un modelo aprendido.
- Combina altura de copa y proporción de retornos para proponer cobertura abierta, vegetación baja, arbolado disperso, cobertura arbórea densa, claros potenciales y arbolado alto candidato.
- Separa las clases en capas con colores de revisión y permite seguir aprendiendo/refinando clases con ejemplos locales.
- Conserva altura media, proporción de retornos, área, anchura estimada, fuente y estado de revisión en los objetos CART.
- Sin aprendizaje local, las áreas se identifican explícitamente como clases preliminares. Ninguna clase asigna transitabilidad ni se acepta automáticamente.

## Verificación

- Pruebas de conversión a capas editables y persistencia de métricas/estado de revisión.
- Ejecutar `npm test` para la batería completa.
