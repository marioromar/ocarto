# Ocarto v1.121 (v221)

Los elementos artificiales detectados por clases LAS se añaden directamente al mapa CART en capas editables y separadas: edificios (clase 6, símbolo 521), tendidos eléctricos (clase 14, símbolo 510) y apoyos (clase 15, símbolo provisional del catálogo, código OCAD/ISOM pendiente de confirmar). Las áreas de edificios conservan sus contornos angulares; las líneas de tendido quedan como geometrías Bézier editables. Cada objeto conserva la clase LAS, procedencia, geometría y advertencia de revisión.

La clase LAS no confirma que un polígono sea un edificio permanente ni que un eje represente el tendido completo; los apoyos son centroides de celdas, no posiciones topográficas verificadas. Revisar los resultados y validar el símbolo de apoyos contra la plantilla de mapa antes de exportar a OCAD/OMAP. Repetir la operación no vuelve a añadir objetos con la misma geometría.
