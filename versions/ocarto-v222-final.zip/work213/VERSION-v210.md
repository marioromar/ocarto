# Ocarto v1.110 (v210)

## Más celdas para el análisis LiDAR

- Se duplica el límite del mosaico de área de 500.000 a 1.000.000 de celdas por modelo de terreno o vegetación.
- Los validadores del MDT, curvas, vegetación, análisis de vaguadas y exportadores/vectorizadores aceptan el nuevo tamaño.
- Se mantiene la resolución inicial de 0,5 m y el mínimo configurable de 0,1 m. El área debe seguir recortándose para el tamaño de celda y la memoria disponible.

## Verificación

- `npm test`: 66 pruebas superadas; la prueba de navegador se omite porque Chromium no está instalado.
- Pruebas de mosaico LiDAR real a 0,5 m y 0,25 m realizadas en v209 con tesela PNOA de 10.852.474 puntos.
- Versión visible: v1.110.
