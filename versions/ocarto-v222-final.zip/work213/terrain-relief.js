/* Optional georeferenced terrain images from the prepared ground grid. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.OcartoTerrainRelief=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const MAX_PIXELS=12000000,MAX_CELLS=1000000;
function render(points,cell,mode='multidirectional',options={}){
 cell=Number(cell);if(!Number.isFinite(cell)||cell<.1)throw Error('La celda del relieve debe ser de 0,1 m o mayor');
 if(!Array.isArray(points)||!points.length||points.length>MAX_CELLS)throw Error('Prepara primero una rejilla de terreno LiDAR válida');
 if(!['multidirectional','slope','local-relief','roughness'].includes(mode))throw Error('Modo de imagen de relieve no válido');
 const radius=mode==='roughness'?Number(options.radius??1):0;if(mode==='roughness'&&(!Number.isInteger(radius)||radius<1||radius>3))throw Error('El radio de rugosidad debe ser de 1 a 3 celdas');
 let minI=Infinity,maxI=-Infinity,minJ=Infinity,maxJ=-Infinity;const values=new Map();
 for(const p of points){if(!Array.isArray(p)||p.length<3||!p.slice(0,3).every(Number.isFinite))throw Error('Cota MDT inválida');const i=Math.floor(p[0]/cell),j=Math.floor(p[1]/cell),key=i+','+j;if(values.has(key))throw Error('Hay más de una cota en una celda MDT');values.set(key,p[2]);minI=Math.min(minI,i);maxI=Math.max(maxI,i);minJ=Math.min(minJ,j);maxJ=Math.max(maxJ,j)}
 const width=maxI-minI+1,height=maxJ-minJ+1;if(width*height>MAX_PIXELS)throw Error('La imagen de relieve sería demasiado grande; vuelve a preparar el MDT con una celda mayor');if(mode==='roughness'&&width*height>MAX_CELLS)throw Error('La imagen de rugosidad supera 1 000 000 de celdas de salida; prepara el MDT con una celda mayor o recorta el área');
 const grid=new Float32Array(width*height);grid.fill(NaN);for(const [key,z] of values){const [i,j]=key.split(',').map(Number);grid[(maxJ-j)*width+i-minI]=z}
 const rgba=new Uint8ClampedArray(width*height*4),azimuths=Array.from({length:8},(_,i)=>i*Math.PI/4),altitude=Math.PI/4,roughness=mode==='roughness'?new Float32Array(width*height):null;if(roughness)roughness.fill(NaN);
 const at=(x,y)=>x<0||y<0||x>=width||y>=height?NaN:grid[y*width+x];
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  const index=y*width+x,z=grid[index],px=index*4;if(!Number.isFinite(z))continue;
  const west=at(x-1,y),east=at(x+1,y),north=at(x,y-1),south=at(x,y+1);
  const gradient=(a,b,center)=>Number.isFinite(a)&&Number.isFinite(b)?(b-a)/(2*cell):Number.isFinite(b)?(b-center)/cell:Number.isFinite(a)?(center-a)/cell:0;
  const dx=gradient(west,east,z),dy=gradient(south,north,z),slope=Math.atan(Math.hypot(dx,dy));let shade;
  if(mode==='slope')shade=Math.round(255*(1-slope/(Math.PI/2)));
  else if(mode==='local-relief'){
   let sum=0,n=0;for(let yy=Math.max(0,y-4);yy<=Math.min(height-1,y+4);yy++)for(let xx=Math.max(0,x-4);xx<=Math.min(width-1,x+4);xx++){const v=at(xx,yy);if(Number.isFinite(v)){sum+=v;n++}}
   const relief=z-(n?sum/n:z);shade=Math.round(Math.max(0,Math.min(255,128+relief*24)));
  }else if(mode==='roughness'){
   const sums=[0,0,0,0,0,0];let n=0,uv=0,uh=0,vh=0;for(let yy=Math.max(0,y-radius);yy<=Math.min(height-1,y+radius);yy++)for(let xx=Math.max(0,x-radius);xx<=Math.min(width-1,x+radius);xx++){const h=at(xx,yy);if(!Number.isFinite(h))continue;const u=(xx-x)*cell,v=(y-yy)*cell;n++;sums[0]++;sums[1]+=u;sums[2]+=v;sums[3]+=h;sums[4]+=u*u;sums[5]+=v*v;uv+=u*v;uh+=u*h;vh+=v*h}
   if(n<4){rgba[px+3]=0;continue}
   const matrix=[[sums[0],sums[1],sums[2]],[sums[1],sums[4],uv],[sums[2],uv,sums[5]]],rhs=[sums[3],uh,vh];
   let validFit=true;for(let col=0;col<3;col++){let pivot=col;for(let row=col+1;row<3;row++)if(Math.abs(matrix[row][col])>Math.abs(matrix[pivot][col]))pivot=row;if(Math.abs(matrix[pivot][col])<1e-12){validFit=false;break}if(pivot!==col){[matrix[pivot],matrix[col]]=[matrix[col],matrix[pivot]];[rhs[pivot],rhs[col]]=[rhs[col],rhs[pivot]]}const d=matrix[col][col];for(let j=col;j<3;j++)matrix[col][j]/=d;rhs[col]/=d;for(let row=0;row<3;row++)if(row!==col){const factor=matrix[row][col];for(let j=col;j<3;j++)matrix[row][j]-=factor*matrix[col][j];rhs[row]-=factor*rhs[col]}}
   if(!validFit||!Number.isFinite(rhs[0])){rgba[px+3]=0;continue}let error=0;for(let yy=Math.max(0,y-radius);yy<=Math.min(height-1,y+radius);yy++)for(let xx=Math.max(0,x-radius);xx<=Math.min(width-1,x+radius);xx++){const h=at(xx,yy);if(!Number.isFinite(h))continue;const u=(xx-x)*cell,v=(y-yy)*cell,e=h-(rhs[0]+rhs[1]*u+rhs[2]*v);error+=e*e}roughness[index]=Math.sqrt(error/n);
  }else{
   let illum=0;for(const az of azimuths){const aspect=Math.atan2(dy,-dx);illum+=Math.max(0,Math.cos(altitude)*Math.cos(slope)+Math.sin(altitude)*Math.sin(slope)*Math.cos(az-aspect))}
   shade=Math.round(40+215*illum/azimuths.length);
  }
  if(mode!=='roughness'){rgba[px]=rgba[px+1]=rgba[px+2]=shade;rgba[px+3]=255}
 }
 let roughnessRange=null;if(mode==='roughness'){const sample=[];let max=0;for(let i=0;i<roughness.length;i++)if(Number.isFinite(roughness[i])&&roughness[i]>0){max=Math.max(max,roughness[i]);if(i%Math.max(1,Math.floor(roughness.length/20000))===0)sample.push(roughness[i])}sample.sort((a,b)=>a-b);const percentile95=sample.length?sample[Math.min(sample.length-1,Math.floor((sample.length-1)*.95))]:0,upper=Math.max(percentile95,max*.01,.001);roughnessRange={p95_m:+percentile95.toFixed(4),displayMax_m:+upper.toFixed(4),max_m:+max.toFixed(4),radiusCells:radius};for(let i=0;i<roughness.length;i++){const px=i*4,v=roughness[i];if(!Number.isFinite(v))continue;const t=Math.max(0,Math.min(1,v/upper));rgba[px]=Math.round(248-180*t);rgba[px+1]=Math.round(244-198*t);rgba[px+2]=Math.round(232-207*t);rgba[px+3]=255}}
 const left=minI*cell,top=(maxJ+1)*cell,worldFile=[cell,0,0,-cell,left+cell/2,top-cell/2].join('\n')+'\n';
 const names={multidirectional:'sombreado multidireccional del MDT de suelo',slope:'pendiente del MDT de suelo en escala de grises', 'local-relief':'relieve local respecto a una ventana de 9 × 9 celdas',roughness:'rugosidad local como RMS de residuos tras descontar el plano del terreno'};
 return{width,height,rgba,cell,cells:values.size,bounds:{left,bottom:minJ*cell,right:(maxI+1)*cell,top},worldFile,method:names[mode],mode,roughnessRange};
}
return{render,MAX_PIXELS,MAX_CELLS};
});
