# Ocarto v1.122 (v222)

La exportación del Feature Map explica qué aporta cada archivo geográfico. El ZIP incluye el PNG y los archivos laterales PGW y PRJ con el mismo nombre base: PGW conserva la posición y el tamaño de píxel; PRJ identifica el CRS. La ayuda y el LEEME indican que hay que conservarlos juntos y cargarlos como plantilla para mantener la georreferencia.

Todas las plantillas de imagen —incluido el Feature Map— ofrecen por separado el modo «Transparente» u «Opaca» y un deslizador de opacidad. Empiezan en modo transparente al 65 %; puedes ajustar cada una para superponerla a la vegetación. El raster conserva transparencia en las zonas sin datos.

El Feature Map es un sombreado de retornos LiDAR entre las alturas sobre suelo elegidas, destinado a inspección visual. No clasifica ni dibuja automáticamente elementos cartográficos.

Verificación: suite completa de pruebas del proyecto.
