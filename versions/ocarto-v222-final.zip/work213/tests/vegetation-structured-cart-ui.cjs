'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
assert.match(html,/Añadir vegetación estructurada al mapa CART/);
assert.match(html,/\$\('addVegetationCandidates'\)\.disabled=!vegetationRows\.length/);
assert.match(html,/vegetationVectorOptions\(\{overrides:S\.vegetationPreview\?\.overrides,classOverrides:S\.vegetationPreview\?\.classOverrides\}\)/);
assert.match(html,/clases preliminares por altura y densidad/);
assert.match(html,/Revisa y corrige las clases antes de exportar; quedan guardadas en \.cart/i);
console.log('✓ vegetación por altura/densidad se incorpora a CART sin exigir un modelo entrenado');
