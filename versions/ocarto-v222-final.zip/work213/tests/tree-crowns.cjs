'use strict';
const assert=require('node:assert/strict'),M=require('../tree-crowns.js');
const rows=[];for(let y=0;y<7;y++)for(let x=0;x<10;x++)rows.push({x:x+.5,y:y+.5,canopy_max_above_ground_m:1,canopy_mean_above_ground_m:.5,vegetation_return_fraction:.2,vegetation_points:2});
const set=(x,y,h)=>{rows[y*10+x].canopy_max_above_ground_m=h;rows[y*10+x].canopy_mean_above_ground_m=h*.7};set(2,2,5);set(3,2,4);set(7,2,12);set(7,3,6);set(7,6,1);
const fc=M.detect(rows,1,{minHeight:2,largeHeight:8,radius:2,minSeparation:3});assert.equal(fc.features.length,2);assert.deepEqual(fc.features.map(f=>f.properties.symbol_candidate),['417','418']);assert.deepEqual(fc.features.map(f=>f.properties.tree_size_class),['large','small']);assert.ok(fc.features.every(f=>f.properties.review_required&&!f.properties.auto_accept));
assert.equal(M.detect(rows,1,{minHeight:6,largeHeight:8,radius:2,minSeparation:3}).features.length,1);assert.throws(()=>M.detect([],0),/celda/);assert.throws(()=>M.detect([],1,{largeHeight:1}),/Parámetros/);
console.log('✓ copas LiDAR: máximos locales, separación, umbral y símbolo por altura');
