# Ocarto v1.112 (v212)

## Alturas y colores configurables para el PNG de copa

- La paleta del PNG de altura de copa admite cuatro puntos de altura y color editables. Los valores iniciales son 0 m amarillo, 0,3 m rojo, 2 m verde y 5 m blanco.
- Los colores se interpolan de forma continua entre las alturas configuradas. Por encima de la última altura se conserva su color.
- La configuración se incluye en el archivo de proyecto y se restaura al abrirlo. Los proyectos anteriores reciben la paleta inicial.
- El ZIP de imagen incluye la leyenda de alturas y colores en `METADATOS.json`.

## Verificación

- `npm test`: 66 pruebas superadas; la prueba de navegador se omite porque Chromium no está instalado.
- Se comprueban colores en cada altura de referencia, la interpolación, el color por encima del último punto y la validación de entradas.
- La exportación de navegador con Chromium no pudo ejecutarse en este entorno.
