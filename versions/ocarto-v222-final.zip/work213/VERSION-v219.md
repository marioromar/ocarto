# Ocarto v1.119 (v219)

Detecta máximos locales de altura de copa para proponer árboles individuales a partir del análisis LiDAR. Permite ajustar altura mínima, altura de corte entre árbol pequeño y grande, radio de búsqueda y separación mínima. Añade las propuestas directamente al proyecto CART en dos capas vectoriales: arbolado pequeño (símbolo 418) y árbol aislado (símbolo 417). Los atributos conservan altura de copa, densidad, tamaño de celda y parámetros de detección; todos quedan marcados para revisión y no se aceptan automáticamente. Repetir la operación no duplica copas ya incorporadas.

La altura y los máximos locales son aproximaciones: las copas próximas pueden juntarse, y arbustos u otros objetos elevados pueden confundirse con árboles. Revisar su posición y clase antes de convertir el proyecto a OCAD/OMAP.
