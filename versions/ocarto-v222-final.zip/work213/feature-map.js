/* Ocarto v1.113: shaded near-ground LiDAR Feature Map renderer. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.OcartoFeatureMap=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const MAX_PIXELS=12000000,MAX_CELLS=1000000;
function render(cells,cell){
 cell=Number(cell);if(!Number.isFinite(cell)||cell<.1)throw Error('La celda del Feature Map debe ser de 0,1 m o mayor');
 const ii=cells?.i,jj=cells?.j,hh=cells?.height;if(!ii||!jj||!hh||ii.length!==jj.length||ii.length!==hh.length||!ii.length||ii.length>MAX_CELLS)throw Error('No hay celdas válidas para el Feature Map');
 let minI=Infinity,maxI=-Infinity,minJ=Infinity,maxJ=-Infinity;const values=new Map();
 for(let k=0;k<ii.length;k++){const i=Number(ii[k]),j=Number(jj[k]),h=Number(hh[k]);if(!Number.isSafeInteger(i)||!Number.isSafeInteger(j)||!Number.isFinite(h)||h<0)throw Error('Celda Feature Map inválida');const key=i+','+j;if(values.has(key))throw Error('Celda duplicada en Feature Map');values.set(key,h);minI=Math.min(minI,i);maxI=Math.max(maxI,i);minJ=Math.min(minJ,j);maxJ=Math.max(maxJ,j)}
 const width=maxI-minI+1,height=maxJ-minJ+1;if(width*height>MAX_PIXELS)throw Error('Imagen Feature Map demasiado grande; usa una celda mayor');
 const grid=new Float32Array(width*height);grid.fill(NaN);for(const [key,h] of values){const [i,j]=key.split(',').map(Number);grid[(maxJ-j)*width+(i-minI)]=h}
 const rgba=new Uint8ClampedArray(width*height*4),az=315*Math.PI/180,alt=45*Math.PI/180,zFactor=2;
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){const at=y*width+x,h=grid[at];if(!Number.isFinite(h))continue;
  const sample=(sx,sy)=>{const xx=Math.max(0,Math.min(width-1,sx)),yy=Math.max(0,Math.min(height-1,sy)),v=grid[yy*width+xx];return Number.isFinite(v)?v:h};
  const dx=(sample(x+1,y)-sample(x-1,y))/(2*cell)*zFactor,dy=(sample(x,y+1)-sample(x,y-1))/(2*cell)*zFactor,slope=Math.atan(Math.hypot(dx,dy)),aspect=Math.atan2(dy,-dx);
  const illumination=Math.max(0,Math.cos(alt)*Math.cos(slope)+Math.sin(alt)*Math.sin(slope)*Math.cos(az-aspect)),shade=Math.round(40+215*illumination),p=at*4;rgba[p]=rgba[p+1]=rgba[p+2]=shade;rgba[p+3]=255;
 }
 const left=minI*cell,top=(maxJ+1)*cell,worldFile=[cell,0,0,-cell,left+cell/2,top-cell/2].join('\n')+'\n';
 return{width,height,rgba,cell,cells:ii.length,bounds:{left,bottom:minJ*cell,right:(maxI+1)*cell,top},worldFile,method:'sombreado del relieve de retornos entre las alturas configuradas sobre el suelo local'};
}
return{render,MAX_PIXELS,MAX_CELLS};
});
