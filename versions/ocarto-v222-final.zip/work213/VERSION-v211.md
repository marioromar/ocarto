# Ocarto v1.111 (v211)

## Vegetación vectorial en OCAD y OMAP

- El paquete de vegetación incluye ahora un archivo `.omap` editable para OpenOrienteering Mapper, además de DXF por capas para importar en OCAD y GeoJSON de respaldo.
- Los polígonos OMAP conservan sus coordenadas métricas, escala del mapa, CRS cuando está indicado, clases y colores de vegetación.
- Áreas con huecos interiores se mantienen completas en GeoJSON y se contabilizan como omitidas en DXF/OMAP para no cerrar claros por error.
- El botón de vectorización identifica claramente la exportación conjunta OCAD + OMAP.

## Verificación

- `npm test`: 66 pruebas superadas; comprobados DXF/CRT, archivo OMAP y clases/áreas con huecos.
- Sintaxis validada en los 65 scripts de `index.html`; prueba de navegador omitida porque Chromium no está instalado.
- Versión visible: v1.111.
