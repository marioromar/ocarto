# Ocarto v1.114 (v214)

## Proyecto CART y áreas nativas de vegetación

- El archivo de proyecto principal se guarda con extensión `.cart`; el formato interno valida y conserva capas, objetos, coordenadas, ajustes y modelos de Ocarto. Se siguen pudiendo abrir proyectos `.ocarto` anteriores.
- La vectorización por alturas crea áreas editables coloreadas en una nueva capa del mapa Ocarto. Las áreas se pueden seleccionar, modificar, deshacer y guardar dentro de `.cart`.
- Las curvas de nivel LiDAR se incorporan como líneas editables en su propia capa y también se guardan en `.cart`.
- DXF queda como opción de conversión secundaria, no como salida principal. OMAP y la conversión a OCAD `.ocd` son herramientas separadas planificadas; la escritura nativa `.ocd` aún está pendiente.
- Los objetos con huecos se omiten de la incorporación automática de altura para no rellenar claros.

## Funcionalidad previa

El Feature Map LiDAR continúa siendo un raster independiente georreferenciado; analiza retornos de todas las clases en un intervalo de altura sobre suelo local y genera PNG, PGW y PRJ.

## Verificación

- Batería completa de pruebas ejecutada con `npm test`.
- Las pruebas de navegador requieren Chromium; si no está disponible, se omiten.
