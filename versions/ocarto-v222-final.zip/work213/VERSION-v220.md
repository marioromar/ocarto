# Ocarto v1.120 (v220)

Los detectores de rocas, muros/escarpes y vaguadas incorporan sus resultados directamente como objetos editables en el mapa CART, agrupados en capas LiDAR que indican que requieren revisión. Las rocas usan el símbolo provisional de roca aislada (204) o roca grande (205), según la prominencia local. Muros y escarpes usan el símbolo provisional de muro franqueable (513); los ejes de vaguada usan curso de agua pequeño (305). Los atributos de cada objeto conservan las métricas del detector, la procedencia y el aviso de revisión. Las líneas se crean con geometría Bézier editable.

El MDT no permite confirmar por sí solo que un desnivel sea muro, ni diferenciar arroyo, canal o surco; tampoco confirma que un resalte sea roca y no tocón o escalón. Por eso las capas y atributos indican que los símbolos son provisionales. Se pueden cambiar antes de exportar a OCAD/OMAP. Repetir una detección no añade de nuevo objetos con la misma geometría.
