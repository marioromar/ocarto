/* Douglas–Peucker simplification that keeps endpoints and marked corner/dash vertices. */
(function(root){
  'use strict';
  const distanceToSegment=(p,a,b)=>{const dx=b.x-a.x,dy=b.y-a.y,len2=dx*dx+dy*dy;if(!len2)return Math.hypot(p.x-a.x,p.y-a.y);const t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/len2));return Math.hypot(p.x-(a.x+t*dx),p.y-(a.y+t*dy))};
  function simplify(path,tolerance=1,{closed=false}={}){
    if(!Array.isArray(path))throw Error('Geometría no válida');
    const points=path.map(p=>{if(!p||!Number.isFinite(p.x)||!Number.isFinite(p.y))throw Error('Vértice no válido');return {...p}});
    if(closed&&points.length>3&&points[0].x===points.at(-1).x&&points[0].y===points.at(-1).y)points.pop();
    if(points.length<(closed?3:2)||!Number.isFinite(tolerance)||tolerance<=0)return points;
    let winding=0;if(closed)for(let i=0;i<points.length;i++){const a=points[i],b=points[(i+1)%points.length];winding+=a.x*b.y-b.x*a.y}const orientation=winding>=0?1:-1;
    const work=closed?[...points,{...points[0]}]:points,n=work.length,last=n-1,keep=new Uint8Array(n),anchors=[0];
    for(let i=1;i<last;i++){
      const p=work[i];if(p.vertexType==='corner'||p.vertexType==='dash'){anchors.push(i);continue}
      const a=work[i-1],b=work[i+1],ax=p.x-a.x,ay=p.y-a.y,bx=b.x-p.x,by=b.y-p.y,al=Math.hypot(ax,ay),bl=Math.hypot(bx,by);
      if(al<tolerance||bl<tolerance)continue;
      const cosine=(ax*bx+ay*by)/(al*bl),cross=ax*by-ay*bx;
      if((closed?cosine<.5&&cross*orientation<0:cosine<-.7))anchors.push(i);
    }
    anchors.push(last);anchors.sort((a,b)=>a-b);for(const i of anchors)keep[i]=1;
    for(let k=1;k<anchors.length;k++){
      const start=anchors[k-1],end=anchors[k];if(end<=start+1)continue;
      const stack=[[start,end]];
      while(stack.length){const [a,b]=stack.pop();let best=-1,max=tolerance;for(let i=a+1;i<b;i++){const d=distanceToSegment(work[i],work[a],work[b]);if(d>max){max=d;best=i}}if(best>=0){keep[best]=1;stack.push([a,best],[best,b])}}
    }
    let result=work.filter((_,i)=>keep[i]);if(closed)result.pop();
    if(closed&&result.length<3){const selected=new Set([...work.map((_,i)=>keep[i]?i:-1).filter(i=>i>=0),last]);for(const i of [Math.floor(last/3),Math.floor(2*last/3)])if(selected.size<4)selected.add(i);result=[...selected].filter(i=>i<last).sort((a,b)=>a-b).map(i=>({...work[i]}))}
    return result;
  }
  function sampleBezier(points,steps=24){
    if(!Array.isArray(points)||points.length<2||!Number.isInteger(steps)||steps<4||steps>256)throw Error('Curva Bézier no válida');
    const out=[{...points[0]}];
    for(let i=0;i<points.length-1;i++){
      const a=points[i],b=points[i+1],dx=b.x-a.x,dy=b.y-a.y,av=a.outTangent||a.tangent||{x:dx/3,y:dy/3},bi=b.inTangent||(b.tangent?{x:-b.tangent.x,y:-b.tangent.y}:{x:-dx/3,y:-dy/3}),c1={x:a.x+av.x,y:a.y+av.y},c2={x:b.x+bi.x,y:b.y+bi.y};
      for(let j=1;j<=steps;j++){const t=j/steps,u=1-t,p={x:u*u*u*a.x+3*u*u*t*c1.x+3*u*t*t*c2.x+t*t*t*b.x,y:u*u*u*a.y+3*u*u*t*c1.y+3*u*t*t*c2.y+t*t*t*b.y};if(j===steps)Object.assign(p,b);out.push(p)}
    }
    return out;
  }
  function pointSegmentDistance(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;if(!l2)return Math.hypot(p.x-a.x,p.y-a.y);const t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/l2));return Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy)}
  function directedPathDistance(from,to){let max=0;for(const p of from){let best=Infinity;for(let i=1;i<to.length;i++)best=Math.min(best,pointSegmentDistance(p,to[i-1],to[i]));max=Math.max(max,best)}return max}
  function simplifyBezierLine(points,tolerance=1,{steps=24,curveTools=root.OcartoNaturalCurves}={}){
    if(!Number.isFinite(tolerance)||tolerance<0)throw Error('Tolerancia no válida');
    if(tolerance===0)return null;
    if(!curveTools||typeof curveTools.apply!=='function')throw Error('Conversor Bézier no disponible');
    if(!Array.isArray(points)||points.length<3)return null;
    const original=sampleBezier(points,steps);let candidate=null,proposal=tolerance;
    for(let attempt=0;attempt<12;attempt++,proposal*=2){const reduced=simplify(original,proposal);if(reduced.length<points.length){candidate=reduced;break}}
    if(!candidate||candidate.length<2)return null;
    const converted=curveTools.apply({type:'line',points:candidate.map(({tangent,inTangent,outTangent,...p})=>p)});
    if(converted?.curve==='bezier'){
      // Preserve the endpoint derivatives when collapsing several original
      // segments into fewer ones; this exactly recovers subdivided cubics.
      const ratio=(points.length-1)/(converted.points.length-1),first=points[0],next=points[1],last=points.at(-1),prev=points.at(-2),out=first.outTangent||first.tangent||{x:(next.x-first.x)/3,y:(next.y-first.y)/3},incoming=last.inTangent||(last.tangent?{x:-last.tangent.x,y:-last.tangent.y}:{x:-(last.x-prev.x)/3,y:-(last.y-prev.y)/3});
      converted.points[0].outTangent={x:out.x*ratio,y:out.y*ratio};converted.points.at(-1).inTangent={x:incoming.x*ratio,y:incoming.y*ratio};
      const fitted=sampleBezier(converted.points,steps),error=Math.max(directedPathDistance(original,fitted),directedPathDistance(fitted,original));
      if(error<=tolerance)return converted.points;
    }
    return null;
  }
  root.OcartoSimplifyTools={simplify,sampleBezier,simplifyBezierLine};if(typeof module!=='undefined'&&module.exports)module.exports=root.OcartoSimplifyTools;
})(typeof window!=='undefined'?window:globalThis);
